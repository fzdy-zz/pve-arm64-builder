package PVE::HA::Tools;

use strict;
use warnings;
use JSON;

use PVE::JSONSchema;
use PVE::Tools;
use PVE::ProcFSTools;

# return codes used in the ha environment
# mainly by the resource agents
use constant {
    SUCCESS => 0, # action finished as expected
    ERROR => 1, # action was erroneous
    ETRY_AGAIN => 2, # action was erroneous and needs to be repeated
    EWRONG_NODE => 3, # needs to fixup the service location
    EUNKNOWN_SERVICE_TYPE => 4, # no plugin for this type service found
    EUNKNOWN_COMMAND => 5,
    EINVALID_PARAMETER => 6,
    EUNKNOWN_SERVICE => 7, # service not found
    IGNORED => 8, # action was ignored for some good reason
};

# get constants out of package in a somewhat easy way
use base 'Exporter';
our @EXPORT_OK = qw(SUCCESS ERROR EWRONG_NODE EUNKNOWN_SERVICE_TYPE
    EUNKNOWN_COMMAND EINVALID_PARAMETER ETRY_AGAIN EUNKNOWN_SERVICE IGNORED);
our %EXPORT_TAGS = ('exit_codes' => [@EXPORT_OK]);

PVE::JSONSchema::register_format('pve-ha-resource-id', \&pve_verify_ha_resource_id);

sub pve_verify_ha_resource_id {
    my ($sid, $noerr) = @_;

    if ($sid !~ m/^[a-z]+:\S+$/) {
        return undef if $noerr;
        die "value does not look like a valid ha resource id\n";
    }
    return $sid;
}

PVE::JSONSchema::register_standard_option(
    'pve-ha-resource-id',
    {
        description => "HA resource ID. This consists of a resource type followed by a resource"
            . " specific name, separated with colon (example: vm:100 / ct:100).",
        typetext => "<type>:<name>",
        type => 'string',
        format => 'pve-ha-resource-id',
    },
);

PVE::JSONSchema::register_standard_option(
    'pve-ha-resource-id-list',
    {
        description =>
            "List of HA resource IDs. This consists of a list of resource types followed"
            . " by a resource specific name separated with a colon (example: vm:100,ct:101).",
        typetext => "<type>:<name>{,<type>:<name>}*",
        type => 'string',
        format => 'pve-ha-resource-id-list',
    },
);

PVE::JSONSchema::register_format('pve-ha-resource-or-vm-id', \&pve_verify_ha_resource_or_vm_id);

sub pve_verify_ha_resource_or_vm_id {
    my ($sid, $noerr) = @_;

    if ($sid !~ m/^([a-z]+:\S+|\d+)$/) {
        return undef if $noerr;
        die "value does not look like a valid ha resource id\n";
    }
    return $sid;
}

PVE::JSONSchema::register_standard_option(
    'pve-ha-resource-or-vm-id',
    {
        description => "HA resource ID. This consists of a resource type followed by a resource"
            . " specific name, separated with colon (example: vm:100 / ct:100). For virtual machines and"
            . " containers, you can simply use the VM or CT id as a shortcut (example: 100).",
        typetext => "<type>:<name>",
        type => 'string',
        format => 'pve-ha-resource-or-vm-id',
    },
);

PVE::JSONSchema::register_format('pve-ha-node', \&pve_verify_ha_node);

sub pve_verify_ha_node {
    my ($node, $noerr) = @_;

    if ($node !~ m/^([a-zA-Z0-9]([a-zA-Z0-9\-]*[a-zA-Z0-9])?)(:\d+)?$/) {
        return undef if $noerr;
        die "value does not look like a valid ha node\n";
    }
    return $node;
}

PVE::JSONSchema::register_standard_option(
    'pve-ha-node-list',
    {
        description => "List of cluster node names with optional priority.",
        verbose_description =>
            "List of cluster node members, where a priority can be given to each"
            . " node. A resource will run on the available nodes with the highest priority. If"
            . " there are more nodes in the highest priority class, the resources will get"
            . " distributed to those nodes. The priorities have a relative meaning only. The"
            . " higher the number, the higher the priority.",
        type => 'string',
        format => 'pve-ha-node-list',
        typetext => '<node>[:<pri>]{,<node>[:<pri>]}*',
    },
);

sub parse_node_priority {
    my ($value, $noerr) = @_;

    if ($value =~ m/^([a-zA-Z0-9]([a-zA-Z0-9\-]*[a-zA-Z0-9])?)(:(\d+))?$/) {
        # node without priority set defaults to priority 0
        return ($1, int($4 // 0));
    }

    return undef if $noerr;
    die "unable to parse HA node entry '$value'\n";
}

PVE::JSONSchema::register_standard_option(
    'pve-ha-group-id',
    {
        description => "The HA group identifier.",
        type => 'string',
        format => 'pve-configid',
    },
);

PVE::JSONSchema::register_standard_option(
    'pve-ha-rule-id',
    {
        description => "HA rule identifier.",
        type => 'string',
        format => 'pve-configid',
    },
);

sub read_json_from_file {
    my ($filename, $default) = @_;

    my $data;

    if (defined($default) && (!-f $filename)) {
        $data = $default;
    } else {
        my $raw = PVE::Tools::file_get_contents($filename);
        $data = decode_json($raw);
    }

    return $data;
}

sub write_json_to_file {
    my ($filename, $data) = @_;

    my $raw = encode_json($data);

    PVE::Tools::file_set_contents($filename, $raw);
}

sub count_fenced_services {
    my ($ss, $node) = @_;

    my $count = 0;

    foreach my $sid (keys %$ss) {
        my $sd = $ss->{$sid};
        next if !$sd->{node};
        next if $sd->{node} ne $node;
        my $req_state = $sd->{state};
        next if !defined($req_state);
        if ($req_state eq 'fence') {
            $count++;
            next;
        }
    }

    return $count;
}

sub count_active_services {
    my ($ss, $node) = @_;

    my $active_count = 0;

    for my $sid (keys %$ss) {
        my $sd = $ss->{$sid};
        my $target = $sd->{target}; # count as active if we are the target.
        next if (!$sd->{node} || $sd->{node} ne $node) && (!$target || $target ne $node);
        my $req_state = $sd->{state};
        next if !defined($req_state);
        next if $req_state eq 'stopped';
        # NOTE: 'ignored' ones are already dropped by the manager from service_status
        next if $req_state eq 'freeze';
        # erroneous services are not managed by HA, don't count them as active
        next if $req_state eq 'error';
        # request_start is for (optional) better node selection for stop -> started transition
        next if $req_state eq 'request_start';

        $active_count++;
    }

    return $active_count;
}

# Returns the set of services that need their transient state machine transition
# completed before a disarm-ha command can finish. With $node set, restricts to
# services owned by that node (used by the LRM to decide whether to stay active
# despite mode=disarm); without $node, returns the cluster-wide set (used by the
# CRM in handle_disarm to decide whether to defer).
sub get_disarm_deferring_services {
    my ($ss, $node) = @_;

    my $disarm_deferring_sids = {};
    my @disarm_deferring_states = qw(fence recovery migrate relocate);

    for my $sid (keys %$ss) {
        my ($state, $current_node) = $ss->{$sid}->@{qw(state node)};

        next if $node && $current_node ne $node;

        $disarm_deferring_sids->{$sid} = 1 if grep { $state eq $_ } @disarm_deferring_states;
    }

    return $disarm_deferring_sids;
}

sub get_verbose_service_state {
    my ($service_state, $service_conf) = @_;

    return 'deleting' if !$service_conf;

    my $req = $service_conf->{state} // 'ignored';
    return 'ignored' if $req eq 'ignored';

    return 'not found' if !defined($service_conf->{node});

    # service not yet processed by manager
    return 'queued' if !defined($service_state);
    my $cur = $service_state->{state};

    # give fast feedback to the user
    my $state = $cur;
    if (!defined($cur)) {
        $state = 'queued';
    } elsif ($cur eq 'stopped') {
        if ($req eq 'started') {
            $state = 'starting';
        } elsif ($req eq 'disabled') {
            $state = 'disabled';
        }
    } elsif ($cur eq 'started') {
        if ($req eq 'stopped' || $req eq 'disabled') {
            $state = 'stopping';
        }
        $state = 'starting' if !$service_state->{running};
    } elsif ($cur eq 'error') {
        if ($req eq 'disabled') {
            $state = 'clearing error flag';
        }
    }

    return $state;
}

sub upid_wait {
    my ($upid, $haenv) = @_;

    my $waitfunc = sub {
        my $task = PVE::Tools::upid_encode(shift);
        $haenv->log('info', "Task '$task' still active, waiting");
    };

    PVE::ProcFSTools::upid_wait($upid, $waitfunc, 5);
}

sub has_min_version {
    my ($version, $min_version) = @_;

    my $get_version_parts = sub {
        my ($version_str) = @_;

        return $version_str =~ m/^(\d+)\.(\d+)(?:\.|-)(\d+)(?:~(\d+))?/;
    };

    my ($major, $minor, $patch, $rev) = $get_version_parts->($version);
    my ($min_major, $min_minor, $min_patch, $min_rev) = $get_version_parts->($min_version);

    return 0 if $major < $min_major;
    return 0 if $major == $min_major && $minor < $min_minor;
    return 0 if $major == $min_major && $minor == $min_minor && $patch < $min_patch;

    $min_rev //= 0;
    return 0
        if $major == $min_major
        && $minor == $min_minor
        && $patch == $min_patch
        && defined($rev)
        && $rev < $min_rev;

    return 1;
}

sub get_ha_resource_type {
    my ($pve_resource_type) = @_;

    if ($pve_resource_type eq 'lxc') {
        return 'ct';
    } elsif ($pve_resource_type eq 'qemu') {
        return 'vm';
    } else {
        die "unknown PVE resource type '$pve_resource_type'";
    }
}

# bash auto completion helper

# NOTE: we use PVE::HA::Config here without declaring an 'use' clause above as
# an hack. It uses the PVE::Cluster module from pve-cluster, which we do not
# have nor want as dependency in the simulator - where the completion helpers
# are never called. The PVE::CLI::ha_manager package pulls it in for us.

sub complete_sid {
    my ($cmd, $pname, $cur) = @_;

    my $cfg = PVE::HA::Config::read_resources_config();

    my $res = [];

    if ($cmd eq 'add') {

        my $vmlist = PVE::Cluster::get_vmlist();

        while (my ($vmid, $info) = each %{ $vmlist->{ids} }) {

            my $type = eval { get_ha_resource_type($info->{type}) };
            next if $@; # silently ignore unknown pve types

            my $sid = "$type:$vmid";

            next if $cfg->{ids}->{$sid};

            push @$res, $sid;
        }

    } else {

        foreach my $sid (keys %{ $cfg->{ids} }) {
            push @$res, $sid;
        }
    }

    return $res;
}

sub complete_enabled_sid {
    my $cfg = PVE::HA::Config::read_resources_config();

    my $res = [];
    foreach my $sid (keys %{ $cfg->{ids} }) {
        my $state = $cfg->{ids}->{$sid}->{state} // 'started';
        next if $state ne 'started';
        push @$res, $sid;
    }

    return $res;
}

sub complete_disabled_sid {
    my $cfg = PVE::HA::Config::read_resources_config();

    my $res = [];
    foreach my $sid (keys %{ $cfg->{ids} }) {
        my $state = $cfg->{ids}->{$sid}->{state} // 'started';
        next if $state eq 'started';
        push @$res, $sid;
    }

    return $res;
}

sub complete_group {
    my ($cmd, $pname, $cur) = @_;

    my $cfg = PVE::HA::Config::read_group_config();

    my $res = [];
    if ($cmd ne 'groupadd') {

        foreach my $group (keys %{ $cfg->{ids} }) {
            push @$res, $group;
        }

    }

    return $res;
}

sub complete_rule {
    my ($cmd, $pname, $cur) = @_;

    my $cfg = PVE::HA::Config::read_rules_config();

    my $res = [];
    foreach my $rule (keys %{ $cfg->{ids} }) {
        push @$res, $rule;
    }

    return $res;
}

1;
