package PVE::HA::Sim::Hardware;

# Simulate Hardware resources

# power supply for nodes: on/off
# network connection to nodes: on/off
# watchdog devices for nodes

use strict;
use warnings;

use Fcntl qw(:DEFAULT :flock);
use File::Copy;
use File::Path qw(make_path remove_tree);
use IO::File;
use JSON;
use POSIX qw(strftime EINTR);

use PVE::HA::FenceConfig;
use PVE::HA::Groups;

my $watchdog_timeout = 60;

my $default_service_cpu = 2.0;
my $default_service_maxcpu = 4.0;
my $default_service_mem = 2048 * 1024**2;
my $default_service_maxmem = 4096 * 1024**2;

my $default_node_maxcpu = 24.0;
my $default_node_maxmem = 131072 * 1024**2;

# Status directory layout
#
# configuration
#
# $testdir/cmdlist                    Command list for simulation
# $testdir/hardware_status            Hardware description (number of nodes, ...)
# $testdir/manager_status             CRM status (start with {})
# $testdir/rules_config               Constraints / Rules configuration
# $testdir/service_config             Service configuration
# $testdir/static_service_stats       Static service usage information (cpu, memory)
# $testdir/groups                     HA groups configuration
# $testdir/service_status_<node>      Service status
# $testdir/datacenter.cfg             Datacenter wide HA configuration

#
# runtime status for simulation system
#
# $testdir/status/cluster_locks        Cluster locks
# $testdir/status/hardware_status      Hardware status (power/network on/off)
# $testdir/status/static_service_stats Static service usage information (cpu, memory)
# $testdir/status/watchdog_status      Watchdog status
#
# runtime status
#
# $testdir/status/lrm_status_<node>           LRM status
# $testdir/status/manager_status              CRM status
# $testdir/status/crm_commands                CRM command queue
# $testdir/status/service_config              Service configuration
# $testdir/status/service_status_<node>       Service status
# $testdir/status/groups                      HA groups configuration

sub read_lrm_status {
    my ($self, $node) = @_;

    my $filename = "$self->{statusdir}/lrm_status_$node";

    return PVE::HA::Tools::read_json_from_file($filename, {});
}

sub write_lrm_status {
    my ($self, $node, $status_obj) = @_;

    my $filename = "$self->{statusdir}/lrm_status_$node";

    PVE::HA::Tools::write_json_to_file($filename, $status_obj);
}

sub read_hardware_status_nolock {
    my ($self) = @_;

    my $filename = "$self->{statusdir}/hardware_status";

    my $raw = PVE::Tools::file_get_contents($filename);
    my $cstatus = decode_json($raw);

    return $cstatus;
}

sub write_hardware_status_nolock {
    my ($self, $cstatus) = @_;

    my $filename = "$self->{statusdir}/hardware_status";

    PVE::Tools::file_set_contents($filename, encode_json($cstatus));
}

sub read_service_config {
    my ($self) = @_;

    my $filename = "$self->{statusdir}/service_config";
    my $conf = PVE::HA::Tools::read_json_from_file($filename);

    foreach my $sid (keys %$conf) {
        my $d = $conf->{$sid};

        die "service '$sid' without assigned node!" if !$d->{node};

        if ($sid =~ m/^(vm|ct|fa):(\d+)$/) {
            $d->{type} = $1;
            $d->{name} = $2;
        } else {
            die "implement me";
        }
        $d->{state} = 'disabled' if !$d->{state};
        $d->{state} = 'started' if $d->{state} eq 'enabled'; # backward compatibility
        $d->{failback} = 1 if !defined($d->{failback});
        $d->{'auto-rebalance'} = 1 if !defined($d->{'auto-rebalance'});
        $d->{max_restart} = 1 if !defined($d->{max_restart});
        $d->{max_relocate} = 1 if !defined($d->{max_relocate});
    }

    return $conf;
}

my sub update_single_service_config_inplace {
    my ($conf, $sid, $param, $delete) = @_;

    my $sconf = $conf->{$sid} || die "no such resource '$sid'\n";

    foreach my $k (%$param) {
        $sconf->{$k} = $param->{$k};
    }

    if ($delete) {
        for my $k (PVE::Tools::split_list($delete)) {
            delete $sconf->{$k};
        }
    }
}

sub update_service_config {
    my ($self, $changes) = @_;

    my $conf = $self->read_service_config();

    for my $sid (sort keys %$changes) {
        my $param = $changes->{$sid}->{param} // {};
        my $delete = $changes->{$sid}->{delete};

        update_single_service_config_inplace($conf, $sid, $param, $delete);
    }

    $self->write_service_config($conf);
}

sub write_service_config {
    my ($self, $conf) = @_;

    $self->{service_config} = $conf;

    my $filename = "$self->{statusdir}/service_config";
    return PVE::HA::Tools::write_json_to_file($filename, $conf);
}

sub read_fence_config {
    my ($self) = @_;

    my $raw = undef;

    my $filename = "$self->{statusdir}/fence.cfg";
    if (-e $filename) {
        $raw = PVE::Tools::file_get_contents($filename);
    }

    return PVE::HA::FenceConfig::parse_config($filename, $raw);
}

sub exec_fence_agent {
    my ($self, $agent, $node, @param) = @_;

    # let all agent succeed and behave the same for now
    $self->sim_hardware_cmd("power $node off", $agent);

    return 0; # EXIT_SUCCESS
}

sub set_service_state {
    my ($self, $sid, $state) = @_;

    my $conf = $self->read_service_config();
    die "no such service '$sid'" if !$conf->{$sid};

    $conf->{$sid}->{state} = $state;

    $self->write_service_config($conf);

    return $conf;
}

sub set_static_service_stats {
    my ($self, $sid, $new_stats) = @_;

    my $conf = $self->read_service_config();
    die "no such service '$sid'" if !$conf->{$sid};

    my $stats = $self->read_static_service_stats();

    if (defined(my $memory = $new_stats->{maxmem})) {
        $stats->{$sid}->{maxmem} = $memory;
    }

    if (defined(my $cpu = $new_stats->{maxcpu})) {
        $stats->{$sid}->{maxcpu} = $cpu;
    }

    $self->write_static_service_stats($stats);
}

sub set_dynamic_service_stats {
    my ($self, $sid, $new_stats) = @_;

    my $conf = $self->read_service_config();
    die "no such service '$sid'" if !$conf->{$sid};

    my $stats = $self->read_dynamic_service_stats();

    if (defined(my $memory = $new_stats->{mem})) {
        $stats->{$sid}->{mem} = $memory;
    }

    if (defined(my $cpu = $new_stats->{cpu})) {
        $stats->{$sid}->{cpu} = $cpu;
    }

    $self->write_dynamic_service_stats($stats);
}

sub add_service {
    my ($self, $sid, $opts, $running) = @_;

    my $conf = $self->read_service_config();
    die "resource ID '$sid' already defined\n" if $conf->{$sid};

    $conf->{$sid} = $opts;
    $conf->{$sid}->@{qw(type name)} = split(/:/, $sid);

    $self->write_service_config($conf);

    my $ss = $self->read_service_status($opts->{node});
    $ss->{$sid} = $running;
    $self->write_service_status($opts->{node}, $ss);

    return $conf;
}

sub delete_service {
    my ($self, $sid) = @_;

    my $conf = $self->read_service_config();

    die "no such service '$sid'" if !$conf->{$sid};

    delete $conf->{$sid};

    $self->write_service_config($conf);

    my $stats = $self->read_static_service_stats();

    delete $stats->{$sid};

    $self->write_static_service_stats($stats);

    return $conf;
}

sub change_service_location {
    my ($self, $sid, $current_node, $new_node) = @_;

    my $conf = $self->read_service_config();

    die "no such service '$sid'\n" if !$conf->{$sid};

    die "current_node for '$sid' does not match ($current_node != $conf->{$sid}->{node})\n"
        if $current_node ne $conf->{$sid}->{node};

    $conf->{$sid}->{node} = $new_node;

    $self->write_service_config($conf);
}

sub service_has_lock {
    my ($self, $sid) = @_;

    my $conf = $self->read_service_config();

    die "no such service '$sid'\n" if !$conf->{$sid};

    return $conf->{$sid}->{lock};
}

sub lock_service {
    my ($self, $sid, $lock) = @_;

    my $conf = $self->read_service_config();

    die "no such service '$sid'\n" if !$conf->{$sid};

    $conf->{$sid}->{lock} = $lock || 'backup';

    $self->write_service_config($conf);

    return $conf;
}

sub unlock_service {
    my ($self, $sid, $lock) = @_;

    my $conf = $self->read_service_config();

    die "no such service '$sid'\n" if !$conf->{$sid};

    my $service_lock = $conf->{$sid}->{lock};

    if (!defined($service_lock)) {
        return undef;
    }

    if (defined($lock) && $service_lock ne $lock) {
        $self->log('warning', "found lock '$service_lock' trying to remove '$lock' lock");
        return undef;
    }

    my $removed_lock = delete $conf->{$sid}->{lock};

    $self->write_service_config($conf);

    return $removed_lock;
}

sub queue_crm_commands_nolock {
    my ($self, $cmd) = @_;

    chomp $cmd;

    my $data = '';
    my $filename = "$self->{statusdir}/crm_commands";
    if (-f $filename) {
        $data = PVE::Tools::file_get_contents($filename);
    }
    $data .= "$cmd\n";
    PVE::Tools::file_set_contents($filename, $data);

    return undef;
}

sub queue_crm_commands {
    my ($self, $cmd) = @_;

    my $code = sub { $self->queue_crm_commands_nolock($cmd); };

    $self->global_lock($code);

    return undef;
}

sub any_pending_crm_command {
    my ($self) = @_;

    my $filename = "$self->{statusdir}/crm_commands";
    my $data;
    if (-f $filename) {
        $data = PVE::Tools::file_get_contents($filename);
    }
    return defined($data) && length $data;
}

sub read_crm_commands {
    my ($self) = @_;

    my $code = sub {
        my $data = '';

        my $filename = "$self->{statusdir}/crm_commands";
        if (-f $filename) {
            $data = PVE::Tools::file_get_contents($filename);
        }
        PVE::Tools::file_set_contents($filename, '');

        return $data;
    };

    return $self->global_lock($code);
}

sub read_rules_config {
    my ($self) = @_;

    my $filename = "$self->{statusdir}/rules_config";
    my $raw = '';
    $raw = PVE::Tools::file_get_contents($filename) if -f $filename;
    my $rules = PVE::HA::Rules->parse_config($filename, $raw);

    # set optional rule parameter's default values
    for my $rule (values %{ $rules->{ids} }) {
        PVE::HA::Rules->set_rule_defaults($rule);
    }

    return $rules;
}

sub write_rules_config {
    my ($self, $rules) = @_;

    my $filename = "$self->{statusdir}/rules_config";

    my $data = PVE::HA::Rules->write_config($filename, $rules);
    PVE::Tools::file_set_contents($filename, $data);
}

sub read_group_config {
    my ($self) = @_;

    my $filename = "$self->{statusdir}/groups";
    my $raw = '';
    $raw = PVE::Tools::file_get_contents($filename) if -f $filename;

    return PVE::HA::Groups->parse_config($filename, $raw);
}

sub delete_group_config {
    my ($self) = @_;

    my $filename = "$self->{statusdir}/groups";
    unlink $filename or die "failed to remove group config: $!\n";
}

sub read_service_status {
    my ($self, $node) = @_;

    my $filename = "$self->{statusdir}/service_status_$node";
    return PVE::HA::Tools::read_json_from_file($filename);
}

sub write_service_status {
    my ($self, $node, $data) = @_;

    my $filename = "$self->{statusdir}/service_status_$node";
    my $res = PVE::HA::Tools::write_json_to_file($filename, $data);

    # fixme: add test if a service runs on two nodes!!!

    return $res;
}

sub read_static_service_stats {
    my ($self) = @_;

    my $filename = "$self->{statusdir}/static_service_stats";
    my $stats = eval { PVE::HA::Tools::read_json_from_file($filename) };
    $self->log('err', "loading static service stats failed - $@") if $@;

    return $stats;
}

sub read_dynamic_service_stats {
    my ($self) = @_;

    my $filename = "$self->{statusdir}/dynamic_service_stats";
    my $stats = eval { PVE::HA::Tools::read_json_from_file($filename) };
    $self->log('err', "loading dynamic service stats failed - $@") if $@;

    return $stats;
}

sub write_static_service_stats {
    my ($self, $stats) = @_;

    my $filename = "$self->{statusdir}/static_service_stats";
    eval { PVE::HA::Tools::write_json_to_file($filename, $stats) };
    $self->log('err', "writing static service stats failed - $@") if $@;
}

sub write_dynamic_service_stats {
    my ($self, $stats) = @_;

    my $filename = "$self->{statusdir}/dynamic_service_stats";
    eval { PVE::HA::Tools::write_json_to_file($filename, $stats) };
    $self->log('err', "writing dynamic service stats failed - $@") if $@;
}

sub new {
    my ($this, $testdir) = @_;

    die "missing testdir" if !$testdir;

    die "testdir '$testdir' does not exist or is not a directory!\n"
        if !-d $testdir;

    my $class = ref($this) || $this;

    my $self = bless {}, $class;

    my $statusdir = $self->{statusdir} = "$testdir/status";

    remove_tree($statusdir);
    mkdir $statusdir;

    # copy initial configuration
    copy("$testdir/manager_status", "$statusdir/manager_status"); # optional

    if (-f "$testdir/rules_config") {
        copy("$testdir/rules_config", "$statusdir/rules_config");
    }

    if (-f "$testdir/groups") {
        copy("$testdir/groups", "$statusdir/groups");
    }

    if (-f "$testdir/service_config") {
        copy("$testdir/service_config", "$statusdir/service_config");
    } else {
        my $conf = {
            'vm:101' => { node => 'node1' },
            'vm:102' => { node => 'node2' },
            'vm:103' => { node => 'node3' },
            'vm:104' => { node => 'node1' },
            'vm:105' => { node => 'node2' },
            'vm:106' => { node => 'node3' },
        };
        $self->write_service_config($conf);
    }

    if (-f "$testdir/hardware_status") {
        copy("$testdir/hardware_status", "$statusdir/hardware_status")
            || die "Copy failed: $!\n";
    } else {
        my $cstatus = {
            node1 => {
                power => 'off',
                network => 'off',
                maxcpu => $default_node_maxcpu,
                maxmem => $default_node_maxmem,
            },
            node2 => {
                power => 'off',
                network => 'off',
                maxcpu => $default_node_maxcpu,
                maxmem => $default_node_maxmem,
            },
            node3 => {
                power => 'off',
                network => 'off',
                maxcpu => $default_node_maxcpu,
                maxmem => $default_node_maxmem,
            },
        };
        $self->write_hardware_status_nolock($cstatus);
    }

    if (-f "$testdir/fence.cfg") {
        copy("$testdir/fence.cfg", "$statusdir/fence.cfg");
    }

    if (-f "$testdir/datacenter.cfg") {
        copy("$testdir/datacenter.cfg", "$statusdir/datacenter.cfg");
    }

    if (-f "$testdir/static_service_stats") {
        copy("$testdir/static_service_stats", "$statusdir/static_service_stats");
    } else {
        my $services = $self->read_service_config();
        my $stats = {
            map {
                $_ => { maxcpu => $default_service_maxcpu, maxmem => $default_service_maxmem }
                }
                keys %$services
        };
        $self->write_static_service_stats($stats);
    }

    if (-f "$testdir/dynamic_service_stats") {
        copy("$testdir/dynamic_service_stats", "$statusdir/dynamic_service_stats");
    } else {
        my $services = $self->read_static_service_stats();
        my $stats = {
            map { $_ => { cpu => $default_service_cpu, mem => $default_service_mem } }
                keys %$services
        };

        $self->write_dynamic_service_stats($stats);
    }

    my $cstatus = $self->read_hardware_status_nolock();

    foreach my $node (sort keys %$cstatus) {
        $self->{nodes}->{$node} = {};

        if (-f "$testdir/service_status_$node") {
            copy("$testdir/service_status_$node", "$statusdir/service_status_$node");
        } else {
            $self->write_service_status($node, {});
        }
    }

    $self->{service_config} = $self->read_service_config();

    return $self;
}

sub save_state {
    my ($self, $testdir) = @_;

    die "missing testdir" if !$testdir;

    die "testdir '$testdir' does not exist or is not a directory!\n"
        if !-d $testdir;

    my $statusdir = $self->{statusdir};
    my $cstatus = $self->read_hardware_status_nolock();

    foreach my $node (sort keys %$cstatus) {
        if (-f "$statusdir/service_status_$node") {
            copy("$statusdir/service_status_$node", "$testdir/service_status_$node");
        }
    }

    if (-f "$statusdir/static_service_stats") {
        copy("$statusdir/static_service_stats", "$testdir/static_service_stats");
    }

    if (-f "$statusdir/datacenter.cfg") {
        copy("$statusdir/datacenter.cfg", "$testdir/datacenter.cfg");
    }

    if (-f "$statusdir/fence.cfg") {
        copy("$statusdir/fence.cfg", "$testdir/fence.cfg");
    }

    if (-f "$statusdir/hardware_status") {
        copy("$statusdir/hardware_status", "$testdir/hardware_status");
    }

    if (-f "$statusdir/service_config") {
        copy("$statusdir/service_config", "$testdir/service_config");
    }

    if (-f "$statusdir/groups") {
        copy("$statusdir/groups", "$testdir/groups");
    }

    if (-f "$statusdir/rules_config") {
        copy("$statusdir/rules_config", "$testdir/rules_config");
    }

    if (-f "$statusdir/manager_status") {
        copy("$statusdir/manager_status", "$testdir/manager_status");
    }

    print "current state saved\n";
}

sub get_time {
    my ($self) = @_;

    die "implement in subclass";
}

sub log {
    my ($self, $level, $msg, $id) = @_;

    chomp $msg;

    my $time = $self->get_time();
    $level = substr($level, 0, 4);

    $id = 'hardware' if !$id;

    printf("%-5s %5d %12s: $msg\n", $level, $time, $id);
}

sub statusdir {
    my ($self, $node) = @_;

    return $self->{statusdir};
}

sub read_datacenter_conf {
    my ($self, $node) = @_;

    my $filename = "$self->{statusdir}/datacenter.cfg";
    return PVE::HA::Tools::read_json_from_file($filename, {});
}

sub write_datacenter_conf {
    my ($self, $conf) = @_;

    my $filename = "$self->{statusdir}/datacenter.cfg";
    PVE::HA::Tools::write_json_to_file($filename, $conf);
}

sub global_lock {
    my ($self, $code, @param) = @_;

    my $lockfile = "$self->{statusdir}/hardware.lck";
    my $fh = IO::File->new(">>$lockfile")
        || die "unable to open '$lockfile'\n";

    my $success;
    for (;;) {
        $success = flock($fh, LOCK_EX);
        if ($success || ($! != EINTR)) {
            last;
        }
        if (!$success) {
            close($fh);
            die "can't acquire lock '$lockfile' - $!\n";
        }
    }

    my $res;

    eval { $res = &$code($fh, @param) };
    my $err = $@;

    close($fh);

    die $err if $err;

    return $res;
}

my $compute_node_info = sub {
    my ($self, $cstatus) = @_;

    my $node_info = {};

    my $node_count = 0;
    my $online_count = 0;

    foreach my $node (keys %$cstatus) {
        my $d = $cstatus->{$node};

        my $online = ($d->{power} eq 'on' && $d->{network} eq 'on') ? 1 : 0;
        $node_info->{$node}->{online} = $online;

        $node_count++;
        $online_count++ if $online;
    }

    my $quorate = ($online_count > int($node_count / 2)) ? 1 : 0;

    if (!$quorate) {
        foreach my $node (keys %$cstatus) {
            my $d = $cstatus->{$node};
            $node_info->{$node}->{online} = 0;
        }
    }

    return ($node_info, $quorate);
};

sub get_node_info {
    my ($self) = @_;

    my $cstatus = $self->read_hardware_status_nolock();
    my ($node_info, $quorate) = &$compute_node_info($self, $cstatus);

    return ($node_info, $quorate);
}

# helper for Sim/ only
sub get_cfs_state {
    my ($self, $node, $state) = @_;

    # TODO: ensure nolock is OK when adding this to RTSim
    my $cstatus = $self->read_hardware_status_nolock();
    my $res = $cstatus->{$node}->{cfs}->{$state};

    # we assume default true if not defined
    return !defined($res) || $res;
}

# simulate hardware commands, the following commands are available:
#   power <node> <on|off>
#   network <node> <on|off>
#   delay <seconds>
#   skip-round <crm|lrm> [<rounds=1>]
#   cfs <node> <rw|update> <work|fail>
#   crm <stop|start>
#   crm enable-node-maintenance <node>
#   crm disable-node-maintenance <node>
#   pve-manager-version <node> set <version>   # note: this is NOT the *ha*-manager version
#   reboot <node>
#   shutdown <node>
#   restart-lrm <node>
#   service <sid> <started|disabled|stopped|ignored>
#   service <sid> <migrate|relocate> <target>
#   service <sid> stop <timeout>
#   service <sid> lock/unlock [lockname]
#   service <sid> add <node> [<request-state=started>] [<running=0>]
#   service <sid> set-static-stats  [maxcpu <cores>] [maxmem <MiB>]
#   service <sid> set-dynamic-stats [cpu <cores>] [mem <MiB>]
#   service <sid> delete
sub sim_hardware_cmd {
    my ($self, $cmdstr, $logid) = @_;

    my $code = sub {
        my ($lock_fh) = @_;

        my $cstatus = $self->read_hardware_status_nolock();

        my ($cmd, $objid, $action, @params) = split(/\s+/, $cmdstr);
        my $param = $params[0]; # for convenience/legacy

        die "sim_hardware_cmd: no node or service for command specified"
            if !$objid;

        my ($node, $sid, $d);

        if ($cmd eq 'service') {
            $sid = PVE::HA::Tools::pve_verify_ha_resource_id($objid);
        } else {
            $node = $objid;
            $d = $self->{nodes}->{$node}
                || die "sim_hardware_cmd: no such node '$node'\n";
        }

        $self->log('info', "execute $cmdstr", $logid);

        if ($cmd eq 'power') {
            die "sim_hardware_cmd: unknown action '$action'\n"
                if $action !~ m/^(on|off)$/;

            if ($cstatus->{$node}->{power} ne $action) {
                if ($action eq 'on') {

                    $d->{crm} = $self->crm_control('start', $d, $lock_fh)
                        if !defined($d->{crm});
                    $d->{lrm} = $self->lrm_control('start', $d, $lock_fh)
                        if !defined($d->{lrm});
                    $d->{lrm_restart} = undef;
                    $cstatus->{$node}->{cfs} = {};

                } else {

                    if ($d->{crm}) {
                        $d->{crm_env}->log('info', "killed by poweroff");
                        $self->crm_control('stop', $d, $lock_fh);
                        $d->{crm} = undef;
                    }
                    if ($d->{lrm}) {
                        $d->{lrm_env}->log('info', "killed by poweroff");
                        $self->lrm_control('stop', $d, $lock_fh);
                        $d->{lrm} = undef;
                        $d->{lrm_restart} = undef;
                    }

                    $self->watchdog_reset_nolock($node);
                    $self->write_service_status($node, {});
                }
            }

            $cstatus->{$node}->{power} = $action;
            $cstatus->{$node}->{network} = $action;
            $cstatus->{$node}->{shutdown} = undef;

            $self->write_hardware_status_nolock($cstatus);

        } elsif ($cmd eq 'network') {
            die "sim_hardware_cmd: unknown network action '$action'"
                if $action !~ m/^(on|off)$/;
            $cstatus->{$node}->{network} = $action;

            $self->write_hardware_status_nolock($cstatus);

        } elsif ($cmd eq 'pve-manager-version') {
            die "sim_hardware_cmd: unknown version action '$action'"
                if $action ne "set";
            $cstatus->{$node}->{'pve-manager-version'} = $param;

            $self->write_hardware_status_nolock($cstatus);

        } elsif ($cmd eq 'cfs') {
            die "sim_hardware_cmd: unknown cfs action '$action' for node '$node'"
                if $action !~ m/^(rw|update)$/;
            die "sim_hardware_cmd: unknown cfs command '$param' for '$action' on node '$node'"
                if $param !~ m/^(work|fail)$/;

            $cstatus->{$node}->{cfs}->{$action} = $param eq 'work';
            $self->write_hardware_status_nolock($cstatus);

        } elsif ($cmd eq 'reboot' || $cmd eq 'shutdown') {
            $cstatus->{$node}->{shutdown} = $cmd;

            $self->write_hardware_status_nolock($cstatus);

            $self->lrm_control('shutdown', $d, $lock_fh) if defined($d->{lrm});
        } elsif ($cmd eq 'restart-lrm') {
            if ($d->{lrm}) {
                $d->{lrm_restart} = 1;
                $self->lrm_control('shutdown', $d, $lock_fh);
            }
        } elsif ($cmd eq 'crm') {

            if ($action eq 'stop') {
                if ($d->{crm}) {
                    $d->{crm_stop} = 1;
                    $self->crm_control('shutdown', $d, $lock_fh);
                }
            } elsif ($action eq 'start') {
                $d->{crm} = $self->crm_control('start', $d, $lock_fh) if !defined($d->{crm});
            } elsif (
                $action eq 'enable-node-maintenance'
                || $action eq 'disable-node-maintenance'
            ) {
                $self->queue_crm_commands_nolock("$action $node");
            } elsif ($action eq 'disarm-ha') {
                my $mode = $params[0];

                die "sim_hardware_cmd: unknown resource mode '$mode'\n"
                    if $mode !~ m/^(freeze|ignore)$/;

                $self->queue_crm_commands_nolock("$action $mode");
            } elsif ($action eq 'arm-ha') {
                $self->queue_crm_commands_nolock("$action");
            } else {
                die "sim_hardware_cmd: unknown action '$action'";
            }

        } elsif ($cmd eq 'service') {
            if (
                $action eq 'started'
                || $action eq 'disabled'
                || $action eq 'stopped'
                || $action eq 'ignored'
            ) {

                $self->set_service_state($sid, $action);

            } elsif ($action eq 'migrate' || $action eq 'relocate') {

                die "sim_hardware_cmd: missing target node for '$action' command"
                    if !$param;

                $self->queue_crm_commands_nolock("$action $sid $param");

            } elsif ($action eq 'stop') {

                die "sim_hardware_cmd: missing timeout for '$action' command"
                    if !defined($param);

                $self->queue_crm_commands_nolock("$action $sid $param");

            } elsif ($action eq 'add') {
                $self->add_service(
                    $sid,
                    { state => $params[1] || 'started', node => $param },
                    $params[2] || 0,
                );

            } elsif ($action eq 'set-static-stats' || $action eq 'set-dynamic-stats') {
                die "sim_hardware_cmd: missing target stat for '$action' command"
                    if !@params;

                my $conversions =
                    $action eq 'set-static-stats'
                    ? { maxcpu => sub { 0.0 + $_[0] }, maxmem => sub { $_[0] * 1024**2 } }
                    : { cpu => sub { 0.0 + $_[0] }, mem => sub { $_[0] * 1024**2 } };

                my %new_stats;
                for my ($target, $val) (@params) {
                    die "sim_hardware_cmd: missing value for '$action $target' command"
                        if !defined($val);

                    my $convert = $conversions->{$target}
                        or die
                        "sim_hardware_cmd: unknown target stat '$target' for '$action' command";

                    $new_stats{$target} = $convert->($val);
                }

                if ($action eq 'set-static-stats') {
                    $self->set_static_service_stats($sid, \%new_stats);
                } else {
                    $self->set_dynamic_service_stats($sid, \%new_stats);
                }
            } elsif ($action eq 'manual-migrate') {

                die "sim_hardware_cmd: missing target node for '$action' command"
                    if !$param;

                my $conf = $self->read_service_config();

                die "sim_hardware_cmd: service '$sid' not configured\n"
                    if !$conf->{$sid};

                my $current_node = $conf->{$sid}->{node}
                    || die "sim_hardware_cmd: service '$sid' has no node\n";

                my $svc_ignored = defined($conf->{$sid}->{state})
                    && $conf->{$sid}->{state} eq 'ignored';

                my $ms = PVE::HA::Tools::read_json_from_file(
                    "$self->{statusdir}/manager_status", {},
                );
                my $disarm_ignored = $ms->{disarm} && $ms->{disarm}->{mode} eq 'ignore';

                die "sim_hardware_cmd: manual-migrate requires service in"
                    . " 'ignored' state or disarm-ha ignore mode\n"
                    if !$svc_ignored && !$disarm_ignored;

                $self->change_service_location($sid, $current_node, $param);

            } elsif ($action eq 'delete') {

                $self->delete_service($sid);

            } elsif ($action eq 'lock') {

                $self->lock_service($sid, $param);

            } elsif ($action eq 'unlock') {

                $self->unlock_service($sid, $param);

            } else {
                die "sim_hardware_cmd: unknown service action '$action' "
                    . "- not implemented\n";
            }
        } else {
            die "sim_hardware_cmd: unknown command '$cmdstr'\n";
        }

        return $cstatus;
    };

    return $self->global_lock($code);
}

# for controlling the resource manager services
sub crm_control {
    my ($self, $action, $data, $lock_fh) = @_;

    die "implement in subclass";
}

sub lrm_control {
    my ($self, $action, $data, $lock_fh) = @_;

    die "implement in subclass";
}

sub run {
    my ($self) = @_;

    die "implement in subclass";
}

my $modify_watchog = sub {
    my ($self, $code) = @_;

    my $update_cmd = sub {

        my $filename = "$self->{statusdir}/watchdog_status";

        my ($res, $wdstatus);

        if (-f $filename) {
            my $raw = PVE::Tools::file_get_contents($filename);
            $wdstatus = decode_json($raw);
        } else {
            $wdstatus = {};
        }

        ($wdstatus, $res) = &$code($wdstatus);

        PVE::Tools::file_set_contents($filename, encode_json($wdstatus));

        return $res;
    };

    return $self->global_lock($update_cmd);
};

sub watchdog_reset_nolock {
    my ($self, $node) = @_;

    my $filename = "$self->{statusdir}/watchdog_status";

    if (-f $filename) {
        my $raw = PVE::Tools::file_get_contents($filename);
        my $wdstatus = decode_json($raw);

        foreach my $id (keys %$wdstatus) {
            delete $wdstatus->{$id} if $wdstatus->{$id}->{node} eq $node;
        }

        PVE::Tools::file_set_contents($filename, encode_json($wdstatus));
    }
}

sub watchdog_check {
    my ($self, $node) = @_;

    my $code = sub {
        my ($wdstatus) = @_;

        my $res = 1;

        foreach my $wfh (keys %$wdstatus) {
            my $wd = $wdstatus->{$wfh};
            next if $wd->{node} ne $node;

            my $ctime = $self->get_time();
            my $tdiff = $ctime - $wd->{update_time};

            if ($tdiff > $watchdog_timeout) { # expired
                $res = 0;
                delete $wdstatus->{$wfh};
            }
        }

        return ($wdstatus, $res);
    };

    return &$modify_watchog($self, $code);
}

my $wdcounter = 0;

sub watchdog_open {
    my ($self, $node) = @_;

    my $code = sub {
        my ($wdstatus) = @_;

        ++$wdcounter;

        my $id = "WD:$node:$$:$wdcounter";

        die "internal error" if defined($wdstatus->{$id});

        $wdstatus->{$id} = {
            node => $node,
            update_time => $self->get_time(),
        };

        return ($wdstatus, $id);
    };

    return &$modify_watchog($self, $code);
}

sub watchdog_close {
    my ($self, $wfh) = @_;

    my $code = sub {
        my ($wdstatus) = @_;

        my $wd = $wdstatus->{$wfh};
        die "no such watchdog handle '$wfh'\n" if !defined($wd);

        my $tdiff = $self->get_time() - $wd->{update_time};
        die "watchdog expired" if $tdiff > $watchdog_timeout;

        delete $wdstatus->{$wfh};

        return ($wdstatus);
    };

    return &$modify_watchog($self, $code);
}

sub watchdog_update {
    my ($self, $wfh) = @_;

    my $code = sub {
        my ($wdstatus) = @_;

        my $wd = $wdstatus->{$wfh};

        die "no such watchdog handle '$wfh'\n" if !defined($wd);

        my $ctime = $self->get_time();
        my $tdiff = $ctime - $wd->{update_time};

        die "watchdog expired" if $tdiff > $watchdog_timeout;

        $wd->{update_time} = $ctime;

        return ($wdstatus);
    };

    return &$modify_watchog($self, $code);
}

my sub get_cluster_service_stats {
    my ($self) = @_;

    my $stats = {};
    for my $sid (keys $self->{service_config}->%*) {
        my $cfg = $self->{service_config}->{$sid};

        $stats->{$sid} = {
            node => $cfg->{node},
            state => $cfg->{state},
            running => $cfg->{state} eq 'started',
            usage => {},
        };
    }

    return $stats;
}

sub get_basic_service_stats {
    my ($self) = @_;

    return get_cluster_service_stats($self);
}

sub get_static_service_stats {
    my ($self) = @_;

    my $stats = get_cluster_service_stats($self);

    my $filename = "$self->{statusdir}/static_service_stats";
    my $usage_stats = eval { PVE::HA::Tools::read_json_from_file($filename) };
    $self->log('warning', "unable to update static service stats cache - $@") if $@;

    for my $sid (keys %$stats) {
        next if !defined($usage_stats->{$sid});

        $stats->{$sid}->{usage} = $usage_stats->{$sid};
    }

    return $stats;
}

sub get_dynamic_service_stats {
    my ($self) = @_;

    my $stats = get_cluster_service_stats($self);
    my $static_stats = $self->read_static_service_stats();
    my $dynamic_stats = $self->read_dynamic_service_stats();

    for my $sid (keys %$stats) {
        $stats->{$sid}->{usage} = {
            $static_stats->{$sid}->%*, $dynamic_stats->{$sid}->%*,
        };

        $self->log('warning', "overcommitted cpu on '$sid'")
            if $stats->{$sid}->{usage}->{cpu} > $stats->{$sid}->{usage}->{maxcpu};
        $self->log('warning', "overcommitted mem on '$sid'")
            if $stats->{$sid}->{usage}->{mem} > $stats->{$sid}->{usage}->{maxmem};
    }

    return $stats;
}

sub get_static_node_stats {
    my ($self) = @_;

    my $cstatus = $self->read_hardware_status_nolock();

    my $stats = {};
    for my $node (keys $cstatus->%*) {
        $stats->{$node} = { $cstatus->{$node}->%{qw(maxcpu maxmem)} };
    }

    return $stats;
}

sub get_dynamic_node_stats {
    my ($self) = @_;

    my $stats = $self->get_static_node_stats();
    for my $node (keys %$stats) {
        $stats->{$node}->{maxcpu} = $stats->{$node}->{maxcpu} // $default_node_maxcpu;
        $stats->{$node}->{cpu} = $stats->{$node}->{cpu} // 0.0;
        $stats->{$node}->{maxmem} = $stats->{$node}->{maxmem} // $default_node_maxmem;
        $stats->{$node}->{mem} = $stats->{$node}->{mem} // 0;
    }

    my $service_conf = $self->read_service_config();
    my $dynamic_service_stats = $self->get_dynamic_service_stats();

    my $cstatus = $self->read_hardware_status_nolock();
    my $node_service_status = { map { $_ => $self->read_service_status($_) } keys %$cstatus };

    for my $sid (keys %$service_conf) {
        my $node = $service_conf->{$sid}->{node};

        # only add the dynamic load usage to node if service is actually marked
        # as running by the node service status written by the LRM
        if ($node_service_status->{$node}->{$sid}) {
            my ($cpu, $mem) = $dynamic_service_stats->{$sid}->{usage}->@{qw(cpu mem)};

            die "unknown cpu load for '$sid'" if !defined($cpu);
            $stats->{$node}->{cpu} += $cpu;
            $self->log('warning', "overcommitted cpu on '$node'")
                if $stats->{$node}->{cpu} > $stats->{$node}->{maxcpu};

            die "unknown memory usage for '$sid'" if !defined($mem);
            $stats->{$node}->{mem} += $mem;
            $self->log('warning', "overcommitted mem on '$node'")
                if $stats->{$node}->{mem} > $stats->{$node}->{maxmem};
        }
    }

    return $stats;
}

sub get_node_version {
    my ($self, $node) = @_;

    my $cstatus = $self->read_hardware_status_nolock();

    return $cstatus->{$node}->{'pve-manager-version'} // "9.0.0~2";
}

1;
