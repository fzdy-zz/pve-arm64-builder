package ifneeded Rrd 1.7.2 [list load [file join $dir ../rrdtool-tcl/tclrrd1.7.2[info sharedlibextension]]]
