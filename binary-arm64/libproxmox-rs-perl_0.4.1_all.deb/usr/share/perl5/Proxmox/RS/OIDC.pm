package Proxmox::RS::OIDC;
use base 'Proxmox::Lib::Common';
BEGIN { __PACKAGE__->bootstrap(); }
1;
