package PVE::Network::SDN::Controllers::IsisPlugin;

use strict;
use warnings;

use PVE::INotify;
use PVE::JSONSchema qw(get_standard_option);
use PVE::Tools qw(run_command file_set_contents file_get_contents);

use PVE::Network::SDN::Controllers::Plugin;
use PVE::Network::SDN::Zones::Plugin;
use Net::IP;

use base('PVE::Network::SDN::Controllers::Plugin');

sub type {
    return 'isis';
}

PVE::JSONSchema::register_format('pve-sdn-isis-net', \&pve_verify_sdn_isis_net);

sub pve_verify_sdn_isis_net {
    my ($net) = @_;

    if ($net !~ m/^[a-fA-F0-9]{2}(\.[a-fA-F0-9]{4}){3,9}\.[a-fA-F0-9]{2}$/) {
        die "value does not look like a valid isis net\n";
    }
    return $net;
}

sub properties {
    return {
        'isis-domain' => {
            description => "Name of the IS-IS domain.",
            type => 'string',
        },
        'isis-ifaces' => {
            description => "Comma-separated list of interfaces where IS-IS should be active.",
            type => 'string',
            format => 'pve-iface-list',
        },
        'isis-net' => {
            description => "Network Entity title for this node in the IS-IS network.",
            type => 'string',
            format => 'pve-sdn-isis-net',
            pattern => '[a-fA-F0-9]{2}(\.[a-fA-F0-9]{4}){3,9}\.[a-fA-F0-9]{2}',
            minLength => 20,
            maxLength => 50,
        },
    };
}

sub options {
    return {
        'isis-domain' => { optional => 0 },
        'isis-net' => { optional => 0 },
        'isis-ifaces' => { optional => 0 },
        'node' => { optional => 0 },
        'loopback' => { optional => 1 },
    };
}

# Plugin implementation
sub generate_frr_config {
    my ($class, $plugin_config, $controller, $id, $uplinks, $config) = @_;

    my $isis_ifaces = $plugin_config->{'isis-ifaces'};
    my $isis_net = $plugin_config->{'isis-net'};
    my $isis_domain = $plugin_config->{'isis-domain'};
    my $local_node = PVE::INotify::nodename();

    return if !$isis_ifaces || !$isis_net || !$isis_domain;
    return if $local_node ne $plugin_config->{node};

    # Configure IS-IS router
    my $isis_router = $config->{frr}->{isis}->{router}->{$isis_domain} //= {};

    $isis_router->{net} = $isis_net;
    $isis_router->{log_adjacency_changes} = 1;
    $isis_router->{redistribute} = {
        ipv4_connected => "level-1",
        ipv6_connected => "level-1",
    };

    # Configure interfaces
    my $altnames = PVE::Network::altname_mapping();
    my @ifaces = PVE::Tools::split_list($isis_ifaces);

    $config->{frr}->{isis}->{interfaces} //= {};
    for my $iface (sort @ifaces) {
        my $iface_name = $altnames->{$iface} // $iface;
        $config->{frr}->{isis}->{interfaces}->{$iface_name} //= {};
        $config->{frr}->{isis}->{interfaces}->{$iface_name}->{domain} = $isis_domain;
        $config->{frr}->{isis}->{interfaces}->{$iface_name}->{is_ipv4} = 1;
        $config->{frr}->{isis}->{interfaces}->{$iface_name}->{is_ipv6} = 0;
    }

    return $config;
}

sub generate_zone_frr_config {
    my ($class, $plugin_config, $controller, $controller_cfg, $id, $uplinks, $config) = @_;

}

sub on_delete_hook {
    my ($class, $controllerid, $zone_cfg) = @_;

}

sub on_update_hook {
    my ($class, $controllerid, $controller_cfg) = @_;

    # we can only have 1 bgp controller by node
    my $local_node = PVE::INotify::nodename();
    my $controllernb = 0;
    foreach my $id (keys %{ $controller_cfg->{ids} }) {
        next if $id eq $controllerid;
        my $controller = $controller_cfg->{ids}->{$id};
        next if $controller->{type} ne "isis";
        next if $controller->{node} ne $local_node;
        $controllernb++;
        die "only 1 bgp or isis controller can be defined" if $controllernb > 1;
    }
}

1;
