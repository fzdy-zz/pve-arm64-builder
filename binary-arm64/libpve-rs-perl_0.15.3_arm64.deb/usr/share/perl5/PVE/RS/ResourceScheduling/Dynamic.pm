package PVE::RS::ResourceScheduling::Dynamic;
use base 'Proxmox::Lib::PVE';
BEGIN { __PACKAGE__->bootstrap(); }
1;
