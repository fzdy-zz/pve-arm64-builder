package PVE::RS::SDN::WireGuard::PrivateKeys;
use base 'Proxmox::Lib::PVE';
BEGIN { __PACKAGE__->bootstrap(); }
1;
