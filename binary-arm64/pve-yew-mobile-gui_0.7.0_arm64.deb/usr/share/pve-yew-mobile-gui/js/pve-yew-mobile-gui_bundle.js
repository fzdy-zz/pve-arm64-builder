var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// dist/snippets/proxmox-yew-comp-2d55432df813e332/js-helper-module.js
var js_helper_module_exports = {};
__export(js_helper_module_exports, {
  async_sleep: () => async_sleep,
  clear_auth_cookie: () => clear_auth_cookie,
  get_cookie: () => get_cookie,
  set_cookie: () => set_cookie
});
function async_sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
function set_cookie(value) {
  document.cookie = value;
}
function clear_auth_cookie(name) {
  document.cookie = name + "=; expires=Thu, 01-Jan-1970 00:00:01 GMT; SameSite=Lax;";
}
function get_cookie() {
  return document.cookie;
}

// dist/snippets/pwt-c0d8527c7079b018/js-helper-module.js
var js_helper_module_exports2 = {};
__export(js_helper_module_exports2, {
  client_to_svg_coords: () => client_to_svg_coords,
  close_dialog: () => close_dialog,
  hide_popover: () => hide_popover,
  show_dialog: () => show_dialog,
  show_modal_dialog: () => show_modal_dialog,
  show_popover: () => show_popover,
  test_alert: () => test_alert,
  toggle_popover: () => toggle_popover
});
function test_alert() {
  alert("This is a test!");
}
function show_modal_dialog(dialog) {
  dialog.showModal();
  dialog.setAttribute("aria-modal", "true");
}
function show_dialog(dialog) {
  dialog.show();
  dialog.setAttribute("aria-modal", "false");
}
function close_dialog(dialog) {
  dialog.close();
  dialog.removeAttribute("aria-modal");
}
function hide_popover(popover) {
  popover.hidePopover();
}
function show_popover(popover) {
  popover.showPopover();
}
function toggle_popover(popover) {
  popover.togglePopover();
}
function client_to_svg_coords(svg, x, y) {
  const ctm = svg.getScreenCTM();
  if (!ctm) {
    return [x, y];
  }
  const pt = new DOMPoint(x, y);
  const svgPt = pt.matrixTransform(ctm.inverse());
  return [svgPt.x, svgPt.y];
}

// dist/pve-yew-mobile-gui.js
function __wbg_get_imports() {
  const import0 = {
    __proto__: null,
    __wbg_Error_8c4e43fe74559d73: function(arg0, arg1) {
      const ret = Error(getStringFromWasm0(arg0, arg1));
      return ret;
    },
    __wbg_Number_04624de7d0e8332d: function(arg0) {
      const ret = Number(arg0);
      return ret;
    },
    __wbg___wbindgen_boolean_get_bbbb1c18aa2f5e25: function(arg0) {
      const v = arg0;
      const ret = typeof v === "boolean" ? v : void 0;
      return isLikeNone(ret) ? 16777215 : ret ? 1 : 0;
    },
    __wbg___wbindgen_debug_string_0bc8482c6e3508ae: function(arg0, arg1) {
      const ret = debugString(arg1);
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    },
    __wbg___wbindgen_in_47fa6863be6f2f25: function(arg0, arg1) {
      const ret = arg0 in arg1;
      return ret;
    },
    __wbg___wbindgen_is_function_0095a73b8b156f76: function(arg0) {
      const ret = typeof arg0 === "function";
      return ret;
    },
    __wbg___wbindgen_is_object_5ae8e5880f2c1fbd: function(arg0) {
      const val = arg0;
      const ret = typeof val === "object" && val !== null;
      return ret;
    },
    __wbg___wbindgen_is_string_cd444516edc5b180: function(arg0) {
      const ret = typeof arg0 === "string";
      return ret;
    },
    __wbg___wbindgen_is_undefined_9e4d92534c42d778: function(arg0) {
      const ret = arg0 === void 0;
      return ret;
    },
    __wbg___wbindgen_jsval_eq_11888390b0186270: function(arg0, arg1) {
      const ret = arg0 === arg1;
      return ret;
    },
    __wbg___wbindgen_jsval_loose_eq_9dd77d8cd6671811: function(arg0, arg1) {
      const ret = arg0 == arg1;
      return ret;
    },
    __wbg___wbindgen_number_get_8ff4255516ccad3e: function(arg0, arg1) {
      const obj = arg1;
      const ret = typeof obj === "number" ? obj : void 0;
      getDataViewMemory0().setFloat64(arg0 + 8 * 1, isLikeNone(ret) ? 0 : ret, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
    },
    __wbg___wbindgen_string_get_72fb696202c56729: function(arg0, arg1) {
      const obj = arg1;
      const ret = typeof obj === "string" ? obj : void 0;
      var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      var len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    },
    __wbg___wbindgen_throw_be289d5034ed271b: function(arg0, arg1) {
      throw new Error(getStringFromWasm0(arg0, arg1));
    },
    __wbg__wbg_cb_unref_d9b87ff7982e3b21: function(arg0) {
      arg0._wbg_cb_unref();
    },
    __wbg_abort_2f0584e03e8e3950: function(arg0) {
      arg0.abort();
    },
    __wbg_activeElement_1554b6917654f8d6: function(arg0) {
      const ret = arg0.activeElement;
      return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    },
    __wbg_addEventListener_3acb0aad4483804c: function() {
      return handleError(function(arg0, arg1, arg2, arg3) {
        arg0.addEventListener(getStringFromWasm0(arg1, arg2), arg3);
      }, arguments);
    },
    __wbg_addEventListener_c917b5aafbcf493f: function() {
      return handleError(function(arg0, arg1, arg2, arg3, arg4) {
        arg0.addEventListener(getStringFromWasm0(arg1, arg2), arg3, arg4);
      }, arguments);
    },
    __wbg_add_5be83378df680c25: function() {
      return handleError(function(arg0, arg1, arg2) {
        arg0.add(getStringFromWasm0(arg1, arg2));
      }, arguments);
    },
    __wbg_append_a992ccc37aa62dc4: function() {
      return handleError(function(arg0, arg1, arg2, arg3, arg4) {
        arg0.append(getStringFromWasm0(arg1, arg2), getStringFromWasm0(arg3, arg4));
      }, arguments);
    },
    __wbg_arrayBuffer_bb54076166006c39: function() {
      return handleError(function(arg0) {
        const ret = arg0.arrayBuffer();
        return ret;
      }, arguments);
    },
    __wbg_assign_4589c32a26ec6e6f: function() {
      return handleError(function(arg0, arg1, arg2) {
        arg0.assign(getStringFromWasm0(arg1, arg2));
      }, arguments);
    },
    __wbg_attributes_7daadf5ee55f9595: function(arg0) {
      const ret = arg0.attributes;
      return ret;
    },
    __wbg_blur_07f34335e06e5234: function() {
      return handleError(function(arg0) {
        arg0.blur();
      }, arguments);
    },
    __wbg_body_f67922363a220026: function(arg0) {
      const ret = arg0.body;
      return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    },
    __wbg_bottom_c7ec510a18034add: function(arg0) {
      const ret = arg0.bottom;
      return ret;
    },
    __wbg_bubbles_ad88192d3c29e6f9: function(arg0) {
      const ret = arg0.bubbles;
      return ret;
    },
    __wbg_button_d86841d0a03adc44: function(arg0) {
      const ret = arg0.button;
      return ret;
    },
    __wbg_cache_key_57601dac16343711: function(arg0) {
      const ret = arg0.__yew_subtree_cache_key;
      return isLikeNone(ret) ? 4294967297 : ret >>> 0;
    },
    __wbg_call_389efe28435a9388: function() {
      return handleError(function(arg0, arg1) {
        const ret = arg0.call(arg1);
        return ret;
      }, arguments);
    },
    __wbg_cancelBubble_d93ec09e9c46cd6f: function(arg0) {
      const ret = arg0.cancelBubble;
      return ret;
    },
    __wbg_changedTouches_b6ab7be7b1aed8d6: function(arg0) {
      const ret = arg0.changedTouches;
      return ret;
    },
    __wbg_childNodes_75d35de33c9f6fbb: function(arg0) {
      const ret = arg0.childNodes;
      return ret;
    },
    __wbg_children_54099e7692eefa29: function(arg0) {
      const ret = arg0.children;
      return ret;
    },
    __wbg_classList_1a87c34c6d81421e: function(arg0) {
      const ret = arg0.classList;
      return ret;
    },
    __wbg_clearInterval_dd1e598f425db353: function(arg0) {
      const ret = clearInterval(arg0);
      return ret;
    },
    __wbg_clearTimeout_5a54f8841c30079a: function(arg0) {
      const ret = clearTimeout(arg0);
      return ret;
    },
    __wbg_clear_auth_cookie_1c88f50f39562d70: function(arg0, arg1) {
      clear_auth_cookie(getStringFromWasm0(arg0, arg1));
    },
    __wbg_clientHeight_6432ff0d61ccfe7d: function(arg0) {
      const ret = arg0.clientHeight;
      return ret;
    },
    __wbg_clientLeft_df4247f0a5134dd4: function(arg0) {
      const ret = arg0.clientLeft;
      return ret;
    },
    __wbg_clientTop_174b533214aef03a: function(arg0) {
      const ret = arg0.clientTop;
      return ret;
    },
    __wbg_clientWidth_dcf89c40d88df4a3: function(arg0) {
      const ret = arg0.clientWidth;
      return ret;
    },
    __wbg_clientX_a3c5f4ff30e91264: function(arg0) {
      const ret = arg0.clientX;
      return ret;
    },
    __wbg_clientX_ed7d2827ca30c165: function(arg0) {
      const ret = arg0.clientX;
      return ret;
    },
    __wbg_clientY_79ab4711d0597b2c: function(arg0) {
      const ret = arg0.clientY;
      return ret;
    },
    __wbg_clientY_e28509acb9b4a42a: function(arg0) {
      const ret = arg0.clientY;
      return ret;
    },
    __wbg_cloneNode_eaf4ea08ebf633a5: function() {
      return handleError(function(arg0) {
        const ret = arg0.cloneNode();
        return ret;
      }, arguments);
    },
    __wbg_code_dee0dae4730408e1: function(arg0, arg1) {
      const ret = arg1.code;
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    },
    __wbg_composedPath_9154ab2547c668d5: function(arg0) {
      const ret = arg0.composedPath();
      return ret;
    },
    __wbg_contains_1056459c33f961e8: function(arg0, arg1) {
      const ret = arg0.contains(arg1);
      return ret;
    },
    __wbg_contains_6f4d5df35ef8a13a: function(arg0, arg1, arg2) {
      const ret = arg0.contains(getStringFromWasm0(arg1, arg2));
      return ret;
    },
    __wbg_createElementNS_ee00621496b30ec2: function() {
      return handleError(function(arg0, arg1, arg2, arg3, arg4) {
        const ret = arg0.createElementNS(arg1 === 0 ? void 0 : getStringFromWasm0(arg1, arg2), getStringFromWasm0(arg3, arg4));
        return ret;
      }, arguments);
    },
    __wbg_createElement_49f60fdcaae809c8: function() {
      return handleError(function(arg0, arg1, arg2) {
        const ret = arg0.createElement(getStringFromWasm0(arg1, arg2));
        return ret;
      }, arguments);
    },
    __wbg_createTextNode_55029686c9591bf3: function(arg0, arg1, arg2) {
      const ret = arg0.createTextNode(getStringFromWasm0(arg1, arg2));
      return ret;
    },
    __wbg_credentials_1d39041a7405b395: function(arg0) {
      const ret = arg0.credentials;
      return ret;
    },
    __wbg_ctrlKey_09a1b54d77dea92b: function(arg0) {
      const ret = arg0.ctrlKey;
      return ret;
    },
    __wbg_ctrlKey_96ff94f8b18636a3: function(arg0) {
      const ret = arg0.ctrlKey;
      return ret;
    },
    __wbg_debug_46a93995fc6f8820: function(arg0, arg1, arg2, arg3) {
      console.debug(arg0, arg1, arg2, arg3);
    },
    __wbg_delete_3f0023dbe540ae60: function() {
      return handleError(function(arg0, arg1, arg2) {
        delete arg0[getStringFromWasm0(arg1, arg2)];
      }, arguments);
    },
    __wbg_deltaY_eb94120160ac821c: function(arg0) {
      const ret = arg0.deltaY;
      return ret;
    },
    __wbg_disconnect_0a2d26237dfc1e9e: function(arg0) {
      arg0.disconnect();
    },
    __wbg_disconnect_b0b06125d01ce8dc: function(arg0) {
      arg0.disconnect();
    },
    __wbg_dispatchEvent_dc8dcc7ddca11378: function() {
      return handleError(function(arg0, arg1) {
        const ret = arg0.dispatchEvent(arg1);
        return ret;
      }, arguments);
    },
    __wbg_documentElement_723733f86794182a: function(arg0) {
      const ret = arg0.documentElement;
      return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    },
    __wbg_document_ee35a3d3ae34ef6c: function(arg0) {
      const ret = arg0.document;
      return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    },
    __wbg_done_57b39ecd9addfe81: function(arg0) {
      const ret = arg0.done;
      return ret;
    },
    __wbg_entries_58c7934c745daac7: function(arg0) {
      const ret = Object.entries(arg0);
      return ret;
    },
    __wbg_error_3c7d958458bf649b: function(arg0, arg1) {
      var v0 = getArrayJsValueFromWasm0(arg0, arg1).slice();
      wasm.__wbindgen_free(arg0, arg1 * 4, 4);
      console.error(...v0);
    },
    __wbg_error_7534b8e9a36f1ab4: function(arg0, arg1) {
      let deferred0_0;
      let deferred0_1;
      try {
        deferred0_0 = arg0;
        deferred0_1 = arg1;
        console.error(getStringFromWasm0(arg0, arg1));
      } finally {
        wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
      }
    },
    __wbg_error_794d0ffc9d00d5c3: function(arg0, arg1, arg2, arg3) {
      console.error(arg0, arg1, arg2, arg3);
    },
    __wbg_error_9a7fe3f932034cde: function(arg0) {
      console.error(arg0);
    },
    __wbg_fetch_84982a7ef270115d: function(arg0, arg1, arg2) {
      const ret = arg0.fetch(arg1, arg2);
      return ret;
    },
    __wbg_fetch_e6e8e0a221783759: function(arg0, arg1) {
      const ret = arg0.fetch(arg1);
      return ret;
    },
    __wbg_focus_128ff465f65677cc: function() {
      return handleError(function(arg0) {
        arg0.focus();
      }, arguments);
    },
    __wbg_focus_e46131175db6a49d: function() {
      return handleError(function(arg0) {
        arg0.focus();
      }, arguments);
    },
    __wbg_formatToParts_e6c1dd1189daf9b0: function(arg0, arg1) {
      const ret = arg0.formatToParts(arg1);
      return ret;
    },
    __wbg_from_bddd64e7d5ff6941: function(arg0) {
      const ret = Array.from(arg0);
      return ret;
    },
    __wbg_getAttribute_b9f6fc4b689c71b0: function(arg0, arg1, arg2, arg3) {
      const ret = arg1.getAttribute(getStringFromWasm0(arg2, arg3));
      var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      var len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    },
    __wbg_getBoundingClientRect_b5c8c34d07878818: function(arg0) {
      const ret = arg0.getBoundingClientRect();
      return ret;
    },
    __wbg_getComputedStyle_2d1f9dfe4ee7e0b9: function() {
      return handleError(function(arg0, arg1) {
        const ret = arg0.getComputedStyle(arg1);
        return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
      }, arguments);
    },
    __wbg_getDate_db46eca87d2b4907: function(arg0) {
      const ret = arg0.getDate();
      return ret;
    },
    __wbg_getElementById_e34377b79d7285f6: function(arg0, arg1, arg2) {
      const ret = arg0.getElementById(getStringFromWasm0(arg1, arg2));
      return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    },
    __wbg_getElementsByTagName_20b929a7b6e4d14c: function(arg0, arg1, arg2) {
      const ret = arg0.getElementsByTagName(getStringFromWasm0(arg1, arg2));
      return ret;
    },
    __wbg_getFullYear_30ddf266b7612036: function(arg0) {
      const ret = arg0.getFullYear();
      return ret;
    },
    __wbg_getHours_e02e88722301c418: function(arg0) {
      const ret = arg0.getHours();
      return ret;
    },
    __wbg_getItem_0c792d344808dcf5: function() {
      return handleError(function(arg0, arg1, arg2, arg3) {
        const ret = arg1.getItem(getStringFromWasm0(arg2, arg3));
        var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
      }, arguments);
    },
    __wbg_getMinutes_eb73ceeb8231f6f4: function(arg0) {
      const ret = arg0.getMinutes();
      return ret;
    },
    __wbg_getMonth_4af888e76b42bb51: function(arg0) {
      const ret = arg0.getMonth();
      return ret;
    },
    __wbg_getPropertyValue_d6911b2a1f9acba9: function() {
      return handleError(function(arg0, arg1, arg2, arg3) {
        const ret = arg1.getPropertyValue(getStringFromWasm0(arg2, arg3));
        const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
      }, arguments);
    },
    __wbg_getSeconds_d5269a98a03bab5e: function(arg0) {
      const ret = arg0.getSeconds();
      return ret;
    },
    __wbg_get_4fe487fe39ff3573: function(arg0, arg1) {
      const ret = arg0[arg1 >>> 0];
      return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    },
    __wbg_get_941633a1d2f510cb: function() {
      return handleError(function(arg0, arg1, arg2, arg3) {
        const ret = arg1.get(getStringFromWasm0(arg2, arg3));
        var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
      }, arguments);
    },
    __wbg_get_9b94d73e6221f75c: function(arg0, arg1) {
      const ret = arg0[arg1 >>> 0];
      return ret;
    },
    __wbg_get_b3ed3ad4be2bc8ac: function() {
      return handleError(function(arg0, arg1) {
        const ret = Reflect.get(arg0, arg1);
        return ret;
      }, arguments);
    },
    __wbg_get_c073d46b477aea39: function() {
      return handleError(function(arg0, arg1) {
        const ret = arg0.get(arg1);
        return ret;
      }, arguments);
    },
    __wbg_get_cookie_3a484c1295306785: function(arg0) {
      const ret = get_cookie();
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    },
    __wbg_get_d8db2ad31d529ff8: function(arg0, arg1) {
      const ret = arg0[arg1 >>> 0];
      return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    },
    __wbg_get_with_index_58f51d382cbfe8da: function(arg0, arg1) {
      const ret = arg0[arg1 >>> 0];
      return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    },
    __wbg_get_with_index_d26da38d2c038e1a: function(arg0, arg1) {
      const ret = arg0[arg1 >>> 0];
      return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    },
    __wbg_get_with_ref_key_1dc361bd10053bfe: function(arg0, arg1) {
      const ret = arg0[arg1];
      return ret;
    },
    __wbg_go_e709a624d63d9e7d: function() {
      return handleError(function(arg0, arg1) {
        arg0.go(arg1);
      }, arguments);
    },
    __wbg_hasAttribute_5d8f52cb4c739280: function(arg0, arg1, arg2) {
      const ret = arg0.hasAttribute(getStringFromWasm0(arg1, arg2));
      return ret;
    },
    __wbg_hasOwnProperty_6ad24eeb271f4027: function(arg0, arg1) {
      const ret = arg0.hasOwnProperty(arg1);
      return ret;
    },
    __wbg_hash_90eadad0e1447454: function() {
      return handleError(function(arg0, arg1) {
        const ret = arg1.hash;
        const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
      }, arguments);
    },
    __wbg_hash_deda717779bea2af: function(arg0, arg1) {
      const ret = arg1.hash;
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    },
    __wbg_headers_59a2938db9f80985: function(arg0) {
      const ret = arg0.headers;
      return ret;
    },
    __wbg_headers_5a897f7fee9a0571: function(arg0) {
      const ret = arg0.headers;
      return ret;
    },
    __wbg_height_45209601b4c4ede6: function(arg0) {
      const ret = arg0.height;
      return ret;
    },
    __wbg_history_d6c2f9abc6e74880: function() {
      return handleError(function(arg0) {
        const ret = arg0.history;
        return ret;
      }, arguments);
    },
    __wbg_host_fb29f8be35c2517d: function(arg0) {
      const ret = arg0.host;
      return ret;
    },
    __wbg_href_67854c3dd511f6f3: function() {
      return handleError(function(arg0, arg1) {
        const ret = arg1.href;
        const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
      }, arguments);
    },
    __wbg_href_874205b16220eda9: function(arg0, arg1) {
      const ret = arg1.href;
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    },
    __wbg_id_ff64a5892a30d4e9: function(arg0, arg1) {
      const ret = arg1.id;
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    },
    __wbg_identifier_5feaba602edf9981: function(arg0) {
      const ret = arg0.identifier;
      return ret;
    },
    __wbg_indexOf_e5f91887d9e5023e: function(arg0, arg1, arg2) {
      const ret = arg0.indexOf(arg1, arg2);
      return ret;
    },
    __wbg_info_9e602cf10c5c690b: function(arg0, arg1, arg2, arg3) {
      console.info(arg0, arg1, arg2, arg3);
    },
    __wbg_innerHTML_ec0d9b250b6f5bf0: function(arg0, arg1) {
      const ret = arg1.innerHTML;
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    },
    __wbg_innerHeight_54aa104da08becd2: function() {
      return handleError(function(arg0) {
        const ret = arg0.innerHeight;
        return ret;
      }, arguments);
    },
    __wbg_innerWidth_fa95c57321f4f033: function() {
      return handleError(function(arg0) {
        const ret = arg0.innerWidth;
        return ret;
      }, arguments);
    },
    __wbg_insertBefore_1468142836e61a51: function() {
      return handleError(function(arg0, arg1, arg2) {
        const ret = arg0.insertBefore(arg1, arg2);
        return ret;
      }, arguments);
    },
    __wbg_instanceof_ArrayBuffer_c367199e2fa2aa04: function(arg0) {
      let result;
      try {
        result = arg0 instanceof ArrayBuffer;
      } catch (_) {
        result = false;
      }
      const ret = result;
      return ret;
    },
    __wbg_instanceof_Element_9e662f49ab6c6beb: function(arg0) {
      let result;
      try {
        result = arg0 instanceof Element;
      } catch (_) {
        result = false;
      }
      const ret = result;
      return ret;
    },
    __wbg_instanceof_Error_8573fe0b0b480f46: function(arg0) {
      let result;
      try {
        result = arg0 instanceof Error;
      } catch (_) {
        result = false;
      }
      const ret = result;
      return ret;
    },
    __wbg_instanceof_HtmlElement_5abfac207260fd6f: function(arg0) {
      let result;
      try {
        result = arg0 instanceof HTMLElement;
      } catch (_) {
        result = false;
      }
      const ret = result;
      return ret;
    },
    __wbg_instanceof_Node_da04bd8df43deba3: function(arg0) {
      let result;
      try {
        result = arg0 instanceof Node;
      } catch (_) {
        result = false;
      }
      const ret = result;
      return ret;
    },
    __wbg_instanceof_PointerEvent_23f63cc61c6fb6a3: function(arg0) {
      let result;
      try {
        result = arg0 instanceof PointerEvent;
      } catch (_) {
        result = false;
      }
      const ret = result;
      return ret;
    },
    __wbg_instanceof_ShadowRoot_5285adde3587c73e: function(arg0) {
      let result;
      try {
        result = arg0 instanceof ShadowRoot;
      } catch (_) {
        result = false;
      }
      const ret = result;
      return ret;
    },
    __wbg_instanceof_Uint8Array_9b9075935c74707c: function(arg0) {
      let result;
      try {
        result = arg0 instanceof Uint8Array;
      } catch (_) {
        result = false;
      }
      const ret = result;
      return ret;
    },
    __wbg_instanceof_Window_ed49b2db8df90359: function(arg0) {
      let result;
      try {
        result = arg0 instanceof Window;
      } catch (_) {
        result = false;
      }
      const ret = result;
      return ret;
    },
    __wbg_isArray_d314bb98fcf08331: function(arg0) {
      const ret = Array.isArray(arg0);
      return ret;
    },
    __wbg_isContentEditable_f5b0ce009dbd035b: function(arg0) {
      const ret = arg0.isContentEditable;
      return ret;
    },
    __wbg_isIntersecting_6807d592d68e059e: function(arg0) {
      const ret = arg0.isIntersecting;
      return ret;
    },
    __wbg_isSafeInteger_bfbc7332a9768d2a: function(arg0) {
      const ret = Number.isSafeInteger(arg0);
      return ret;
    },
    __wbg_is_f29129f676e5410c: function(arg0, arg1) {
      const ret = Object.is(arg0, arg1);
      return ret;
    },
    __wbg_item_5c82f52b014b3056: function(arg0, arg1) {
      const ret = arg0.item(arg1 >>> 0);
      return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    },
    __wbg_iterator_6ff6560ca1568e55: function() {
      const ret = Symbol.iterator;
      return ret;
    },
    __wbg_key_d41e8e825e6bb0e9: function(arg0, arg1) {
      const ret = arg1.key;
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    },
    __wbg_lastChild_132d67597d5e4aef: function(arg0) {
      const ret = arg0.lastChild;
      return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    },
    __wbg_left_3b7c3c1030d5ca7a: function(arg0) {
      const ret = arg0.left;
      return ret;
    },
    __wbg_length_25b2ccd77d48ecb1: function(arg0) {
      const ret = arg0.length;
      return ret;
    },
    __wbg_length_32ed9a279acd054c: function(arg0) {
      const ret = arg0.length;
      return ret;
    },
    __wbg_length_35a7bace40f36eac: function(arg0) {
      const ret = arg0.length;
      return ret;
    },
    __wbg_length_369d51337c919694: function(arg0) {
      const ret = arg0.length;
      return ret;
    },
    __wbg_length_3f12bc1cab862cc3: function(arg0) {
      const ret = arg0.length;
      return ret;
    },
    __wbg_length_e455564ce5cbf46e: function(arg0) {
      const ret = arg0.length;
      return ret;
    },
    __wbg_listener_id_ed1678830a5b97ec: function(arg0) {
      const ret = arg0.__yew_listener_id;
      return isLikeNone(ret) ? 4294967297 : ret >>> 0;
    },
    __wbg_localStorage_a22d31b9eacc4594: function() {
      return handleError(function(arg0) {
        const ret = arg0.localStorage;
        return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
      }, arguments);
    },
    __wbg_location_df7ca06c93e51763: function(arg0) {
      const ret = arg0.location;
      return ret;
    },
    __wbg_log_24aba2a6d8990b35: function(arg0, arg1, arg2, arg3) {
      console.log(arg0, arg1, arg2, arg3);
    },
    __wbg_matchMedia_91d4fc9729dc3c84: function() {
      return handleError(function(arg0, arg1, arg2) {
        const ret = arg0.matchMedia(getStringFromWasm0(arg1, arg2));
        return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
      }, arguments);
    },
    __wbg_matches_4b5c22bd830f7bb3: function(arg0) {
      const ret = arg0.matches;
      return ret;
    },
    __wbg_message_9ddc4b9a62a7c379: function(arg0) {
      const ret = arg0.message;
      return ret;
    },
    __wbg_name_5e45f1646cfbe53e: function(arg0, arg1) {
      const ret = arg1.name;
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    },
    __wbg_namespaceURI_86e2062c65f0f341: function(arg0, arg1) {
      const ret = arg1.namespaceURI;
      var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      var len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    },
    __wbg_navigator_11364c46e8ea3fe3: function(arg0) {
      const ret = arg0.navigator;
      return ret;
    },
    __wbg_new_0_73afc35eb544e539: function() {
      const ret = /* @__PURE__ */ new Date();
      return ret;
    },
    __wbg_new_22a9eb07a41c8c8a: function() {
      return handleError(function(arg0, arg1) {
        const ret = new Event(getStringFromWasm0(arg0, arg1));
        return ret;
      }, arguments);
    },
    __wbg_new_361308b2356cecd0: function() {
      const ret = new Object();
      return ret;
    },
    __wbg_new_3eb36ae241fe6f44: function() {
      const ret = new Array();
      return ret;
    },
    __wbg_new_64284bd487f9d239: function() {
      return handleError(function() {
        const ret = new Headers();
        return ret;
      }, arguments);
    },
    __wbg_new_72b49615380db768: function(arg0, arg1) {
      const ret = new Error(getStringFromWasm0(arg0, arg1));
      return ret;
    },
    __wbg_new_79e6044f512b1551: function() {
      return handleError(function() {
        const ret = new DOMParser();
        return ret;
      }, arguments);
    },
    __wbg_new_86c8f0b79e48927d: function(arg0, arg1) {
      const ret = new Intl.NumberFormat(arg0, arg1);
      return ret;
    },
    __wbg_new_8a6f238a6ece86ea: function() {
      const ret = new Error();
      return ret;
    },
    __wbg_new_8c6e67a40cee1f83: function() {
      return handleError(function(arg0) {
        const ret = new IntersectionObserver(arg0);
        return ret;
      }, arguments);
    },
    __wbg_new_b949e7f56150a5d1: function() {
      return handleError(function() {
        const ret = new AbortController();
        return ret;
      }, arguments);
    },
    __wbg_new_c2f21774701ddac7: function() {
      return handleError(function(arg0, arg1) {
        const ret = new URL(getStringFromWasm0(arg0, arg1));
        return ret;
      }, arguments);
    },
    __wbg_new_dd2b680c8bf6ae29: function(arg0) {
      const ret = new Uint8Array(arg0);
      return ret;
    },
    __wbg_new_e64d85ddaeec292a: function() {
      return handleError(function(arg0) {
        const ret = new ResizeObserver(arg0);
        return ret;
      }, arguments);
    },
    __wbg_new_from_slice_a3d2629dc1826784: function(arg0, arg1) {
      const ret = new Uint8Array(getArrayU8FromWasm0(arg0, arg1));
      return ret;
    },
    __wbg_new_no_args_1c7c842f08d00ebb: function(arg0, arg1) {
      const ret = new Function(getStringFromWasm0(arg0, arg1));
      return ret;
    },
    __wbg_new_with_base_332baf6f4ebbaae9: function() {
      return handleError(function(arg0, arg1, arg2, arg3) {
        const ret = new URL(getStringFromWasm0(arg0, arg1), getStringFromWasm0(arg2, arg3));
        return ret;
      }, arguments);
    },
    __wbg_new_with_length_a2c39cbe88fd8ff1: function(arg0) {
      const ret = new Uint8Array(arg0 >>> 0);
      return ret;
    },
    __wbg_new_with_str_and_init_a61cbc6bdef21614: function() {
      return handleError(function(arg0, arg1, arg2) {
        const ret = new Request(getStringFromWasm0(arg0, arg1), arg2);
        return ret;
      }, arguments);
    },
    __wbg_nextSibling_2e988d9bbe3e06f0: function(arg0) {
      const ret = arg0.nextSibling;
      return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    },
    __wbg_next_3482f54c49e8af19: function() {
      return handleError(function(arg0) {
        const ret = arg0.next();
        return ret;
      }, arguments);
    },
    __wbg_next_418f80d8f5303233: function(arg0) {
      const ret = arg0.next;
      return ret;
    },
    __wbg_nodeName_fd5af4f06ca67c8e: function(arg0, arg1) {
      const ret = arg1.nodeName;
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    },
    __wbg_nodeType_1a77807cb3800514: function(arg0) {
      const ret = arg0.nodeType;
      return ret;
    },
    __wbg_now_a3af9a2f4bbaa4d1: function() {
      const ret = Date.now();
      return ret;
    },
    __wbg_observe_2a9d63459970a2c1: function(arg0, arg1) {
      arg0.observe(arg1);
    },
    __wbg_observe_50e8800eaf78c18e: function(arg0, arg1) {
      arg0.observe(arg1);
    },
    __wbg_observe_ec59f588a58bf150: function(arg0, arg1, arg2) {
      arg0.observe(arg1, arg2);
    },
    __wbg_ok_87f537440a0acf85: function(arg0) {
      const ret = arg0.ok;
      return ret;
    },
    __wbg_open_d7691c490eaf9349: function() {
      return handleError(function(arg0, arg1, arg2, arg3, arg4, arg5, arg6) {
        const ret = arg0.open(getStringFromWasm0(arg1, arg2), getStringFromWasm0(arg3, arg4), getStringFromWasm0(arg5, arg6));
        return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
      }, arguments);
    },
    __wbg_origin_a9c891fa602b4d40: function() {
      return handleError(function(arg0, arg1) {
        const ret = arg1.origin;
        const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
      }, arguments);
    },
    __wbg_outerHTML_baa741c8917e0c70: function(arg0, arg1) {
      const ret = arg1.outerHTML;
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    },
    __wbg_ownerDocument_9347874c5cad87d7: function(arg0) {
      const ret = arg0.ownerDocument;
      return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    },
    __wbg_parentElement_75863410a8617953: function(arg0) {
      const ret = arg0.parentElement;
      return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    },
    __wbg_parentNode_d44bd5ec58601e45: function(arg0) {
      const ret = arg0.parentNode;
      return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    },
    __wbg_parseFromString_06bbea4ddcf49d6f: function() {
      return handleError(function(arg0, arg1, arg2, arg3) {
        const ret = arg0.parseFromString(getStringFromWasm0(arg1, arg2), __wbindgen_enum_SupportedType[arg3]);
        return ret;
      }, arguments);
    },
    __wbg_parse_708461a1feddfb38: function() {
      return handleError(function(arg0, arg1) {
        const ret = JSON.parse(getStringFromWasm0(arg0, arg1));
        return ret;
      }, arguments);
    },
    __wbg_pathname_b2267fae358b49a7: function() {
      return handleError(function(arg0, arg1) {
        const ret = arg1.pathname;
        const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
      }, arguments);
    },
    __wbg_pathname_cd185643c5c70f28: function(arg0, arg1) {
      const ret = arg1.pathname;
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    },
    __wbg_pointerId_466b1bdcaf2fe835: function(arg0) {
      const ret = arg0.pointerId;
      return ret;
    },
    __wbg_pointerType_ba53c6f18634a26d: function(arg0, arg1) {
      const ret = arg1.pointerType;
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    },
    __wbg_preventDefault_cdcfcd7e301b9702: function(arg0) {
      arg0.preventDefault();
    },
    __wbg_protocol_1cf76689210fbcd2: function(arg0, arg1) {
      const ret = arg1.protocol;
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    },
    __wbg_prototypesetcall_bdcdcc5842e4d77d: function(arg0, arg1, arg2) {
      Uint8Array.prototype.set.call(getArrayU8FromWasm0(arg0, arg1), arg2);
    },
    __wbg_pushState_b8b21dc05883695b: function() {
      return handleError(function(arg0, arg1, arg2, arg3, arg4, arg5) {
        arg0.pushState(arg1, getStringFromWasm0(arg2, arg3), arg4 === 0 ? void 0 : getStringFromWasm0(arg4, arg5));
      }, arguments);
    },
    __wbg_querySelectorAll_5875742f4e11f759: function() {
      return handleError(function(arg0, arg1, arg2) {
        const ret = arg0.querySelectorAll(getStringFromWasm0(arg1, arg2));
        return ret;
      }, arguments);
    },
    __wbg_querySelector_1be4292f202b1597: function() {
      return handleError(function(arg0, arg1, arg2) {
        const ret = arg0.querySelector(getStringFromWasm0(arg1, arg2));
        return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
      }, arguments);
    },
    __wbg_queueMicrotask_0aa0a927f78f5d98: function(arg0) {
      const ret = arg0.queueMicrotask;
      return ret;
    },
    __wbg_queueMicrotask_5bb536982f78a56f: function(arg0) {
      queueMicrotask(arg0);
    },
    __wbg_relatedTarget_fc55ae99c3144e6a: function(arg0) {
      const ret = arg0.relatedTarget;
      return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    },
    __wbg_removeAttribute_87259aab06d9f286: function() {
      return handleError(function(arg0, arg1, arg2) {
        arg0.removeAttribute(getStringFromWasm0(arg1, arg2));
      }, arguments);
    },
    __wbg_removeChild_2f0b06213dbc49ca: function() {
      return handleError(function(arg0, arg1) {
        const ret = arg0.removeChild(arg1);
        return ret;
      }, arguments);
    },
    __wbg_removeEventListener_0c0902ed5009dd9f: function() {
      return handleError(function(arg0, arg1, arg2, arg3, arg4) {
        arg0.removeEventListener(getStringFromWasm0(arg1, arg2), arg3, arg4 !== 0);
      }, arguments);
    },
    __wbg_removeEventListener_e63328781a5b9af9: function() {
      return handleError(function(arg0, arg1, arg2, arg3) {
        arg0.removeEventListener(getStringFromWasm0(arg1, arg2), arg3);
      }, arguments);
    },
    __wbg_removeProperty_a0d2ff8a76ffd2b1: function() {
      return handleError(function(arg0, arg1, arg2, arg3) {
        const ret = arg1.removeProperty(getStringFromWasm0(arg2, arg3));
        const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
      }, arguments);
    },
    __wbg_remove_91efa89f4c02780f: function() {
      return handleError(function(arg0, arg1, arg2, arg3, arg4, arg5, arg6) {
        arg0.remove(getStringFromWasm0(arg1, arg2), getStringFromWasm0(arg3, arg4), getStringFromWasm0(arg5, arg6));
      }, arguments);
    },
    __wbg_remove_e5f8ef4fa8fb0b71: function() {
      return handleError(function(arg0, arg1, arg2, arg3, arg4) {
        arg0.remove(getStringFromWasm0(arg1, arg2), getStringFromWasm0(arg3, arg4));
      }, arguments);
    },
    __wbg_replaceChild_aa18d854c7f3880d: function() {
      return handleError(function(arg0, arg1, arg2) {
        const ret = arg0.replaceChild(arg1, arg2);
        return ret;
      }, arguments);
    },
    __wbg_replaceState_aefa111958f68023: function() {
      return handleError(function(arg0, arg1, arg2, arg3, arg4, arg5) {
        arg0.replaceState(arg1, getStringFromWasm0(arg2, arg3), arg4 === 0 ? void 0 : getStringFromWasm0(arg4, arg5));
      }, arguments);
    },
    __wbg_resolve_002c4b7d9d8f6b64: function(arg0) {
      const ret = Promise.resolve(arg0);
      return ret;
    },
    __wbg_right_154af6c2b1bf0c89: function(arg0) {
      const ret = arg0.right;
      return ret;
    },
    __wbg_scrollHeight_04fd01111276a28d: function(arg0) {
      const ret = arg0.scrollHeight;
      return ret;
    },
    __wbg_scrollHeight_25e40881bfad55b6: function(arg0) {
      const ret = arg0.scrollHeight;
      return ret;
    },
    __wbg_scrollLeft_2b817c7719d17438: function(arg0) {
      const ret = arg0.scrollLeft;
      return ret;
    },
    __wbg_scrollTop_0a3a77f9fcbe038e: function(arg0) {
      const ret = arg0.scrollTop;
      return ret;
    },
    __wbg_scrollTop_4161d2a08060cb06: function(arg0) {
      const ret = arg0.scrollTop;
      return ret;
    },
    __wbg_scrollWidth_d0233d345e3a50fa: function(arg0) {
      const ret = arg0.scrollWidth;
      return ret;
    },
    __wbg_search_143f09a35047e800: function(arg0, arg1) {
      const ret = arg1.search;
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    },
    __wbg_search_1b385e665c888780: function() {
      return handleError(function(arg0, arg1) {
        const ret = arg1.search;
        const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
        getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
      }, arguments);
    },
    __wbg_sessionStorage_ebb0b5c1edca9c2e: function() {
      return handleError(function(arg0) {
        const ret = arg0.sessionStorage;
        return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
      }, arguments);
    },
    __wbg_setAttribute_cc8e4c8a2a008508: function() {
      return handleError(function(arg0, arg1, arg2, arg3, arg4) {
        arg0.setAttribute(getStringFromWasm0(arg1, arg2), getStringFromWasm0(arg3, arg4));
      }, arguments);
    },
    __wbg_setInterval_ed3b5e3c3ebb8a6d: function() {
      return handleError(function(arg0, arg1) {
        const ret = setInterval(arg0, arg1);
        return ret;
      }, arguments);
    },
    __wbg_setItem_cf340bb2edbd3089: function() {
      return handleError(function(arg0, arg1, arg2, arg3, arg4) {
        arg0.setItem(getStringFromWasm0(arg1, arg2), getStringFromWasm0(arg3, arg4));
      }, arguments);
    },
    __wbg_setPointerCapture_420db6f6826eb74b: function() {
      return handleError(function(arg0, arg1) {
        arg0.setPointerCapture(arg1);
      }, arguments);
    },
    __wbg_setProperty_cbb25c4e74285b39: function() {
      return handleError(function(arg0, arg1, arg2, arg3, arg4) {
        arg0.setProperty(getStringFromWasm0(arg1, arg2), getStringFromWasm0(arg3, arg4));
      }, arguments);
    },
    __wbg_setTime_7ff687e524801ea2: function(arg0, arg1) {
      const ret = arg0.setTime(arg1);
      return ret;
    },
    __wbg_setTimeout_db2dbaeefb6f39c7: function() {
      return handleError(function(arg0, arg1) {
        const ret = setTimeout(arg0, arg1);
        return ret;
      }, arguments);
    },
    __wbg_set_3f1d0b984ed272ed: function(arg0, arg1, arg2) {
      arg0[arg1] = arg2;
    },
    __wbg_set_6cb8631f80447a67: function() {
      return handleError(function(arg0, arg1, arg2) {
        const ret = Reflect.set(arg0, arg1, arg2);
        return ret;
      }, arguments);
    },
    __wbg_set_body_9a7e00afe3cfe244: function(arg0, arg1) {
      arg0.body = arg1;
    },
    __wbg_set_cache_key_bb5f908a0e3ee714: function(arg0, arg1) {
      arg0.__yew_subtree_cache_key = arg1 >>> 0;
    },
    __wbg_set_capture_d52e7a585f2933c8: function(arg0, arg1) {
      arg0.capture = arg1 !== 0;
    },
    __wbg_set_cc56eefd2dd91957: function(arg0, arg1, arg2) {
      arg0.set(getArrayU8FromWasm0(arg1, arg2));
    },
    __wbg_set_checked_4b2468680005fbf7: function(arg0, arg1) {
      arg0.checked = arg1 !== 0;
    },
    __wbg_set_cookie_6c14f0ad253d386c: function(arg0, arg1) {
      set_cookie(getStringFromWasm0(arg0, arg1));
    },
    __wbg_set_hash_ef8eaa28bac5a100: function(arg0, arg1, arg2) {
      arg0.hash = getStringFromWasm0(arg1, arg2);
    },
    __wbg_set_headers_cfc5f4b2c1f20549: function(arg0, arg1) {
      arg0.headers = arg1;
    },
    __wbg_set_innerHTML_edd39677e3460291: function(arg0, arg1, arg2) {
      arg0.innerHTML = getStringFromWasm0(arg1, arg2);
    },
    __wbg_set_listener_id_3d14d37a42484593: function(arg0, arg1) {
      arg0.__yew_listener_id = arg1 >>> 0;
    },
    __wbg_set_method_c3e20375f5ae7fac: function(arg0, arg1, arg2) {
      arg0.method = getStringFromWasm0(arg1, arg2);
    },
    __wbg_set_nodeValue_d947eb0a476b80d7: function(arg0, arg1, arg2) {
      arg0.nodeValue = arg1 === 0 ? void 0 : getStringFromWasm0(arg1, arg2);
    },
    __wbg_set_once_56ba1b87a9884c15: function(arg0, arg1) {
      arg0.once = arg1 !== 0;
    },
    __wbg_set_passive_f411e67e6f28687b: function(arg0, arg1) {
      arg0.passive = arg1 !== 0;
    },
    __wbg_set_scrollLeft_8de8fc187e3a6808: function(arg0, arg1) {
      arg0.scrollLeft = arg1;
    },
    __wbg_set_scrollTop_fb454582dda63417: function(arg0, arg1) {
      arg0.scrollTop = arg1;
    },
    __wbg_set_signal_f2d3f8599248896d: function(arg0, arg1) {
      arg0.signal = arg1;
    },
    __wbg_set_subtree_id_32b8ceff55862e29: function(arg0, arg1) {
      arg0.__yew_subtree_id = arg1 >>> 0;
    },
    __wbg_set_tabIndex_eb89b6ffe111cd2c: function(arg0, arg1) {
      arg0.tabIndex = arg1;
    },
    __wbg_set_textContent_3e87dba095d9cdbc: function(arg0, arg1, arg2) {
      arg0.textContent = arg1 === 0 ? void 0 : getStringFromWasm0(arg1, arg2);
    },
    __wbg_set_value_62a965e38b22b38c: function(arg0, arg1, arg2) {
      arg0.value = getStringFromWasm0(arg1, arg2);
    },
    __wbg_set_value_ddc3bd01a8467bf1: function(arg0, arg1, arg2) {
      arg0.value = getStringFromWasm0(arg1, arg2);
    },
    __wbg_shiftKey_5558a3288542c985: function(arg0) {
      const ret = arg0.shiftKey;
      return ret;
    },
    __wbg_shiftKey_564be91ec842bcc4: function(arg0) {
      const ret = arg0.shiftKey;
      return ret;
    },
    __wbg_signal_d1285ecab4ebc5ad: function(arg0) {
      const ret = arg0.signal;
      return ret;
    },
    __wbg_stack_0ed75d68575b0f3c: function(arg0, arg1) {
      const ret = arg1.stack;
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    },
    __wbg_state_da286469d44b98d6: function() {
      return handleError(function(arg0) {
        const ret = arg0.state;
        return ret;
      }, arguments);
    },
    __wbg_static_accessor_GLOBAL_12837167ad935116: function() {
      const ret = typeof global === "undefined" ? null : global;
      return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    },
    __wbg_static_accessor_GLOBAL_THIS_e628e89ab3b1c95f: function() {
      const ret = typeof globalThis === "undefined" ? null : globalThis;
      return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    },
    __wbg_static_accessor_SELF_a621d3dfbb60d0ce: function() {
      const ret = typeof self === "undefined" ? null : self;
      return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    },
    __wbg_static_accessor_WINDOW_f8727f0cf888e0bd: function() {
      const ret = typeof window === "undefined" ? null : window;
      return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    },
    __wbg_statusText_556131a02d60f5cd: function(arg0, arg1) {
      const ret = arg1.statusText;
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    },
    __wbg_status_89d7e803db911ee7: function(arg0) {
      const ret = arg0.status;
      return ret;
    },
    __wbg_stopPropagation_6e5e2a085214ac63: function(arg0) {
      arg0.stopPropagation();
    },
    __wbg_stringify_8d1cc6ff383e8bae: function() {
      return handleError(function(arg0) {
        const ret = JSON.stringify(arg0);
        return ret;
      }, arguments);
    },
    __wbg_style_0b7c9bd318f8b807: function(arg0) {
      const ret = arg0.style;
      return ret;
    },
    __wbg_subtree_id_e65dfcc52d403fd9: function(arg0) {
      const ret = arg0.__yew_subtree_id;
      return isLikeNone(ret) ? 4294967297 : ret >>> 0;
    },
    __wbg_tabIndex_3a5765473bb0b23d: function(arg0) {
      const ret = arg0.tabIndex;
      return ret;
    },
    __wbg_tagName_0cf6d7b647352f04: function(arg0, arg1) {
      const ret = arg1.tagName;
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    },
    __wbg_target_0ee82d8bbe927599: function(arg0) {
      const ret = arg0.target;
      return ret;
    },
    __wbg_target_521be630ab05b11e: function(arg0) {
      const ret = arg0.target;
      return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    },
    __wbg_target_de28a5bc42c8305d: function(arg0) {
      const ret = arg0.target;
      return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
    },
    __wbg_text_083b8727c990c8c0: function() {
      return handleError(function(arg0) {
        const ret = arg0.text();
        return ret;
      }, arguments);
    },
    __wbg_then_0d9fe2c7b1857d32: function(arg0, arg1, arg2) {
      const ret = arg0.then(arg1, arg2);
      return ret;
    },
    __wbg_then_b9e7b3b5f1a9e1b5: function(arg0, arg1) {
      const ret = arg0.then(arg1);
      return ret;
    },
    __wbg_toString_029ac24421fd7a24: function(arg0) {
      const ret = arg0.toString();
      return ret;
    },
    __wbg_top_3d27ff6f468cf3fc: function(arg0) {
      const ret = arg0.top;
      return ret;
    },
    __wbg_touches_55ce167b42bcdf52: function(arg0) {
      const ret = arg0.touches;
      return ret;
    },
    __wbg_value_0546255b415e96c1: function(arg0) {
      const ret = arg0.value;
      return ret;
    },
    __wbg_value_15684899da869c95: function(arg0, arg1) {
      const ret = arg1.value;
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    },
    __wbg_value_65d50ffc48349445: function(arg0, arg1) {
      const ret = arg1.value;
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    },
    __wbg_value_e506a07878790ca0: function(arg0, arg1) {
      const ret = arg1.value;
      const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
      const len1 = WASM_VECTOR_LEN;
      getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
      getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
    },
    __wbg_warn_a40b971467b219c7: function(arg0, arg1, arg2, arg3) {
      console.warn(arg0, arg1, arg2, arg3);
    },
    __wbg_width_ae46cb8e98ee102f: function(arg0) {
      const ret = arg0.width;
      return ret;
    },
    __wbg_x_1c3a1279b05ec817: function(arg0) {
      const ret = arg0.x;
      return ret;
    },
    __wbg_x_95222ef76724a332: function(arg0) {
      const ret = arg0.x;
      return ret;
    },
    __wbg_y_0b4e7ff7d5c0a5d7: function(arg0) {
      const ret = arg0.y;
      return ret;
    },
    __wbg_y_1e7a8eb7080c1c25: function(arg0) {
      const ret = arg0.y;
      return ret;
    },
    __wbindgen_cast_0000000000000001: function(arg0, arg1) {
      const ret = makeMutClosure(arg0, arg1, wasm.wasm_bindgen__closure__destroy__h21452e52395bfbb5, wasm_bindgen__convert__closures_____invoke__h3c9f5dc5f621fbd7);
      return ret;
    },
    __wbindgen_cast_0000000000000002: function(arg0, arg1) {
      const ret = makeMutClosure(arg0, arg1, wasm.wasm_bindgen__closure__destroy__h21452e52395bfbb5, wasm_bindgen__convert__closures_____invoke__h5dba48983ad8b3da);
      return ret;
    },
    __wbindgen_cast_0000000000000003: function(arg0, arg1) {
      const ret = makeClosure(arg0, arg1, wasm.wasm_bindgen__closure__destroy__h044ca20d45028e73, wasm_bindgen__convert__closures________invoke__ha45fcb981b1739ac);
      return ret;
    },
    __wbindgen_cast_0000000000000004: function(arg0, arg1) {
      const ret = makeMutClosure(arg0, arg1, wasm.wasm_bindgen__closure__destroy__h044ca20d45028e73, wasm_bindgen__convert__closures________invoke__ha18352670d56c132);
      return ret;
    },
    __wbindgen_cast_0000000000000005: function(arg0, arg1) {
      const ret = makeClosure(arg0, arg1, wasm.wasm_bindgen__closure__destroy__h044ca20d45028e73, wasm_bindgen__convert__closures_____invoke__haf4357a7f6565689);
      return ret;
    },
    __wbindgen_cast_0000000000000006: function(arg0, arg1) {
      const ret = makeClosure(arg0, arg1, wasm.wasm_bindgen__closure__destroy__h044ca20d45028e73, wasm_bindgen__convert__closures_____invoke__h050d94ac3c22adae);
      return ret;
    },
    __wbindgen_cast_0000000000000007: function(arg0, arg1) {
      const ret = makeClosure(arg0, arg1, wasm.wasm_bindgen__closure__destroy__h044ca20d45028e73, wasm_bindgen__convert__closures_____invoke__h88842f98b7ccd26d);
      return ret;
    },
    __wbindgen_cast_0000000000000008: function(arg0) {
      const ret = arg0;
      return ret;
    },
    __wbindgen_cast_0000000000000009: function(arg0, arg1) {
      const ret = getStringFromWasm0(arg0, arg1);
      return ret;
    },
    __wbindgen_init_externref_table: function() {
      const table = wasm.__wbindgen_externrefs;
      const offset = table.grow(4);
      table.set(0, void 0);
      table.set(offset + 0, void 0);
      table.set(offset + 1, null);
      table.set(offset + 2, true);
      table.set(offset + 3, false);
    }
  };
  return {
    __proto__: null,
    "./pve-yew-mobile-gui_bg.js": import0,
    "./snippets/proxmox-yew-comp-2d55432df813e332/js-helper-module.js": js_helper_module_exports,
    "./snippets/pwt-c0d8527c7079b018/js-helper-module.js": js_helper_module_exports2,
    "./snippets/pwt-c0d8527c7079b018/js-helper-module.js": js_helper_module_exports2,
    "./snippets/pwt-c0d8527c7079b018/js-helper-module.js": js_helper_module_exports2,
    "./snippets/pwt-c0d8527c7079b018/js-helper-module.js": js_helper_module_exports2
  };
}
function wasm_bindgen__convert__closures_____invoke__h5dba48983ad8b3da(arg0, arg1) {
  wasm.wasm_bindgen__convert__closures_____invoke__h5dba48983ad8b3da(arg0, arg1);
}
function wasm_bindgen__convert__closures_____invoke__h88842f98b7ccd26d(arg0, arg1) {
  wasm.wasm_bindgen__convert__closures_____invoke__h88842f98b7ccd26d(arg0, arg1);
}
function wasm_bindgen__convert__closures_____invoke__h3c9f5dc5f621fbd7(arg0, arg1, arg2) {
  wasm.wasm_bindgen__convert__closures_____invoke__h3c9f5dc5f621fbd7(arg0, arg1, arg2);
}
function wasm_bindgen__convert__closures________invoke__ha45fcb981b1739ac(arg0, arg1, arg2) {
  wasm.wasm_bindgen__convert__closures________invoke__ha45fcb981b1739ac(arg0, arg1, arg2);
}
function wasm_bindgen__convert__closures________invoke__ha18352670d56c132(arg0, arg1, arg2) {
  wasm.wasm_bindgen__convert__closures________invoke__ha18352670d56c132(arg0, arg1, arg2);
}
function wasm_bindgen__convert__closures_____invoke__h050d94ac3c22adae(arg0, arg1, arg2) {
  const ptr0 = passArrayJsValueToWasm0(arg2, wasm.__wbindgen_malloc);
  const len0 = WASM_VECTOR_LEN;
  wasm.wasm_bindgen__convert__closures_____invoke__h050d94ac3c22adae(arg0, arg1, ptr0, len0);
}
function wasm_bindgen__convert__closures_____invoke__haf4357a7f6565689(arg0, arg1, arg2, arg3) {
  const ptr0 = passArrayJsValueToWasm0(arg2, wasm.__wbindgen_malloc);
  const len0 = WASM_VECTOR_LEN;
  wasm.wasm_bindgen__convert__closures_____invoke__haf4357a7f6565689(arg0, arg1, ptr0, len0, arg3);
}
var __wbindgen_enum_SupportedType = ["text/html", "text/xml", "application/xml", "application/xhtml+xml", "image/svg+xml"];
function addToExternrefTable0(obj) {
  const idx = wasm.__externref_table_alloc();
  wasm.__wbindgen_externrefs.set(idx, obj);
  return idx;
}
var CLOSURE_DTORS = typeof FinalizationRegistry === "undefined" ? { register: () => {
}, unregister: () => {
} } : new FinalizationRegistry((state) => state.dtor(state.a, state.b));
function debugString(val) {
  const type = typeof val;
  if (type == "number" || type == "boolean" || val == null) {
    return `${val}`;
  }
  if (type == "string") {
    return `"${val}"`;
  }
  if (type == "symbol") {
    const description = val.description;
    if (description == null) {
      return "Symbol";
    } else {
      return `Symbol(${description})`;
    }
  }
  if (type == "function") {
    const name = val.name;
    if (typeof name == "string" && name.length > 0) {
      return `Function(${name})`;
    } else {
      return "Function";
    }
  }
  if (Array.isArray(val)) {
    const length = val.length;
    let debug = "[";
    if (length > 0) {
      debug += debugString(val[0]);
    }
    for (let i = 1; i < length; i++) {
      debug += ", " + debugString(val[i]);
    }
    debug += "]";
    return debug;
  }
  const builtInMatches = /\[object ([^\]]+)\]/.exec(toString.call(val));
  let className;
  if (builtInMatches && builtInMatches.length > 1) {
    className = builtInMatches[1];
  } else {
    return toString.call(val);
  }
  if (className == "Object") {
    try {
      return "Object(" + JSON.stringify(val) + ")";
    } catch (_) {
      return "Object";
    }
  }
  if (val instanceof Error) {
    return `${val.name}: ${val.message}
${val.stack}`;
  }
  return className;
}
function getArrayJsValueFromWasm0(ptr, len) {
  ptr = ptr >>> 0;
  const mem = getDataViewMemory0();
  const result = [];
  for (let i = ptr; i < ptr + 4 * len; i += 4) {
    result.push(wasm.__wbindgen_externrefs.get(mem.getUint32(i, true)));
  }
  wasm.__externref_drop_slice(ptr, len);
  return result;
}
function getArrayU8FromWasm0(ptr, len) {
  ptr = ptr >>> 0;
  return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}
var cachedDataViewMemory0 = null;
function getDataViewMemory0() {
  if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || cachedDataViewMemory0.buffer.detached === void 0 && cachedDataViewMemory0.buffer !== wasm.memory.buffer) {
    cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
  }
  return cachedDataViewMemory0;
}
function getStringFromWasm0(ptr, len) {
  ptr = ptr >>> 0;
  return decodeText(ptr, len);
}
var cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
  if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
    cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
  }
  return cachedUint8ArrayMemory0;
}
function handleError(f, args) {
  try {
    return f.apply(this, args);
  } catch (e) {
    const idx = addToExternrefTable0(e);
    wasm.__wbindgen_exn_store(idx);
  }
}
function isLikeNone(x) {
  return x === void 0 || x === null;
}
function makeClosure(arg0, arg1, dtor, f) {
  const state = { a: arg0, b: arg1, cnt: 1, dtor };
  const real = (...args) => {
    state.cnt++;
    try {
      return f(state.a, state.b, ...args);
    } finally {
      real._wbg_cb_unref();
    }
  };
  real._wbg_cb_unref = () => {
    if (--state.cnt === 0) {
      state.dtor(state.a, state.b);
      state.a = 0;
      CLOSURE_DTORS.unregister(state);
    }
  };
  CLOSURE_DTORS.register(real, state, state);
  return real;
}
function makeMutClosure(arg0, arg1, dtor, f) {
  const state = { a: arg0, b: arg1, cnt: 1, dtor };
  const real = (...args) => {
    state.cnt++;
    const a = state.a;
    state.a = 0;
    try {
      return f(a, state.b, ...args);
    } finally {
      state.a = a;
      real._wbg_cb_unref();
    }
  };
  real._wbg_cb_unref = () => {
    if (--state.cnt === 0) {
      state.dtor(state.a, state.b);
      state.a = 0;
      CLOSURE_DTORS.unregister(state);
    }
  };
  CLOSURE_DTORS.register(real, state, state);
  return real;
}
function passArrayJsValueToWasm0(array, malloc) {
  const ptr = malloc(array.length * 4, 4) >>> 0;
  for (let i = 0; i < array.length; i++) {
    const add = addToExternrefTable0(array[i]);
    getDataViewMemory0().setUint32(ptr + 4 * i, add, true);
  }
  WASM_VECTOR_LEN = array.length;
  return ptr;
}
function passStringToWasm0(arg, malloc, realloc) {
  if (realloc === void 0) {
    const buf = cachedTextEncoder.encode(arg);
    const ptr2 = malloc(buf.length, 1) >>> 0;
    getUint8ArrayMemory0().subarray(ptr2, ptr2 + buf.length).set(buf);
    WASM_VECTOR_LEN = buf.length;
    return ptr2;
  }
  let len = arg.length;
  let ptr = malloc(len, 1) >>> 0;
  const mem = getUint8ArrayMemory0();
  let offset = 0;
  for (; offset < len; offset++) {
    const code = arg.charCodeAt(offset);
    if (code > 127) break;
    mem[ptr + offset] = code;
  }
  if (offset !== len) {
    if (offset !== 0) {
      arg = arg.slice(offset);
    }
    ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
    const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
    const ret = cachedTextEncoder.encodeInto(arg, view);
    offset += ret.written;
    ptr = realloc(ptr, len, offset, 1) >>> 0;
  }
  WASM_VECTOR_LEN = offset;
  return ptr;
}
var cachedTextDecoder = new TextDecoder("utf-8", { ignoreBOM: true, fatal: true });
cachedTextDecoder.decode();
var MAX_SAFARI_DECODE_BYTES = 2146435072;
var numBytesDecoded = 0;
function decodeText(ptr, len) {
  numBytesDecoded += len;
  if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
    cachedTextDecoder = new TextDecoder("utf-8", { ignoreBOM: true, fatal: true });
    cachedTextDecoder.decode();
    numBytesDecoded = len;
  }
  return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}
var cachedTextEncoder = new TextEncoder();
if (!("encodeInto" in cachedTextEncoder)) {
  cachedTextEncoder.encodeInto = function(arg, view) {
    const buf = cachedTextEncoder.encode(arg);
    view.set(buf);
    return {
      read: arg.length,
      written: buf.length
    };
  };
}
var WASM_VECTOR_LEN = 0;
var wasmModule;
var wasm;
function __wbg_finalize_init(instance, module) {
  wasm = instance.exports;
  wasmModule = module;
  cachedDataViewMemory0 = null;
  cachedUint8ArrayMemory0 = null;
  wasm.__wbindgen_start();
  return wasm;
}
async function __wbg_load(module, imports) {
  if (typeof Response === "function" && module instanceof Response) {
    if (typeof WebAssembly.instantiateStreaming === "function") {
      try {
        return await WebAssembly.instantiateStreaming(module, imports);
      } catch (e) {
        const validResponse = module.ok && expectedResponseType(module.type);
        if (validResponse && module.headers.get("Content-Type") !== "application/wasm") {
          console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);
        } else {
          throw e;
        }
      }
    }
    const bytes = await module.arrayBuffer();
    return await WebAssembly.instantiate(bytes, imports);
  } else {
    const instance = await WebAssembly.instantiate(module, imports);
    if (instance instanceof WebAssembly.Instance) {
      return { instance, module };
    } else {
      return instance;
    }
  }
  function expectedResponseType(type) {
    switch (type) {
      case "basic":
      case "cors":
      case "default":
        return true;
    }
    return false;
  }
}
function initSync(module) {
  if (wasm !== void 0) return wasm;
  if (module !== void 0) {
    if (Object.getPrototypeOf(module) === Object.prototype) {
      ({ module } = module);
    } else {
      console.warn("using deprecated parameters for `initSync()`; pass a single object instead");
    }
  }
  const imports = __wbg_get_imports();
  if (!(module instanceof WebAssembly.Module)) {
    module = new WebAssembly.Module(module);
  }
  const instance = new WebAssembly.Instance(module, imports);
  return __wbg_finalize_init(instance, module);
}
async function __wbg_init(module_or_path) {
  if (wasm !== void 0) return wasm;
  if (module_or_path !== void 0) {
    if (Object.getPrototypeOf(module_or_path) === Object.prototype) {
      ({ module_or_path } = module_or_path);
    } else {
      console.warn("using deprecated parameters for the initialization function; pass a single object instead");
    }
  }
  const imports = __wbg_get_imports();
  if (typeof module_or_path === "string" || typeof Request === "function" && module_or_path instanceof Request || typeof URL === "function" && module_or_path instanceof URL) {
    module_or_path = fetch(module_or_path);
  }
  const { instance, module } = await __wbg_load(await module_or_path, imports);
  return __wbg_finalize_init(instance, module);
}
export {
  __wbg_init as default,
  initSync
};
