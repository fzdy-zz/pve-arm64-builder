// 3.8.0
// Proxmox Message Catalog: pve-lang-da.js
__proxmox_i18n_msgcat__ = {"1010534570":["Online"],"102017518":["Aktivér"],"1025870843":["Gruppetilladelse"],"1030781705":["Ingen restriktioner"],"1038759093":["Valg"],"1041399898":["Tilslut"],"1048039038":["Roller"],"1095677363":["Oversigt"],"1097310050":["Indhold"],"1103628980":["Backupjob"],"1117080514":["Tilbage"],"1120365745":["Redigér"],"1121548025":["Oppetid"],"112472755":["Brugere"],"113230335":["Backup"],"1137376136":["Skabeloner"],"1137934931":["Grafikkort"],"1146456703":["Er du sikker på at du vil fjerne dette punkt"],"1155649139":["Er du sikker på at du vil fjerne punktet {0}"],"1162681738":["Genoptage"],"1171724691":["Hukommelsesstørrelse"],"117505411":["Tilladelser"],"1179034313":["Søg"],"125463051":["Log ud"],"1256668313":["Afbryd"],"1258653480":["Indstillinger"],"1266644741":["Stop"],"1277169241":["Ukendt"],"1278843611":["Alle undtagen {0}"],"1288449246":["Upload Subscriptionnøgle"],"1299621093":["Destruér"],"1308245100":["Starttidspunkt"],"1312749210":["CPU-forbrug"],"1313942339":["Ukendt fejl"],"1315717828":["Volume-gruppe"],"133166255":["Backup nu"],"135637716":["Opdatér"],"1358083177":["Storage"],"1364578413":["Type"],"1397651250":["Metode"],"1401934633":["Harddisk"],"1431906062":["Community"],"1432485131":["Generelt"],"1441655762":["Login"],"1445070878":["Migrér"],"1462731997":["Basic"],"1477916441":["Hardware"],"1485672":["Standard"],"1492679118":["Hukommelse"],"1496092135":["Tjek"],"1509197333":["Netværksenhed"],"1510332853":["Skærm"],"1517138453":["Brugernavn"],"1524227104":["Bekræft adgangskode"],"1540552279":["Slet data"],"1558370824":["Næste"],"1569100592":["Klar"],"1572687098":["Noder"],"1573770551":["Version"],"1582017048":["Oversigt"],"1591441098":["Konsol"],"1608836100":["Tid"],"1621507602":["Bruger"],"1637264131":["Pause"],"1637971824":["Puljer"],"1642243064":["Kilde"],"1642511898":["Nej"],"1657093318":["Port"],"1672675413":["Tjenester"],"1680585545":["Diskimage"],"1682907645":["dag"],"1692103706":["Tidszone"],"1696191342":["Swap"],"1704356651":["Skabelon"],"1712097977":["Skærm"],"1725856265":["Beskrivelse"],"1756866391":["DNS-server"],"1768209177":["Hent"],"1769254245":["Netværk"],"1789283792":["Brugt"],"1795931892":["Delt"],"1801905238":["Sti"],"180669460":["IP-adresse"],"180921696":["Genstart"],"180965513":["aldrig"],"1810297992":["Support"],"1827006442":["Login fejlet. Prøv venligst igen"],"182978943":["Start"],"1832687280":["Medlemmer"],"1836253938":["Server"],"1837256131":["Diskforbrug"],"1839360066":["Udløber"],"1843267341":["Tilladte karaktérer"],"1843349479":["Serveroversigt"],"1853244196":["Output"],"1860367182":["stoppet"],"187908228":["Datacenter"],"1882575938":["Eksisterende volume-gruppe"],"1887498962":["Sværhedsgrad"],"1902253047":["Cluster log"],"1911669355":["Sluk"],"1938660593":["Fejl"],"1971275149":["Grupper"],"1974461284":["Alle"],"1985725044":["Ekskludér valgte VMs"],"1989206232":["Ubrugt Disk"],"1989268106":["dage"],"2003021401":["Brugertilladelse"],"2023431579":["Vellykket"],"2025656483":["Pulje"],"2047171115":["Afbryd"],"2053124568":["godt"],"2069659400":["Valg"],"2123320219":["Pakke"],"2138419768":["Start ved boot"],"2142306162":["Format"],"241489403":["Standalone node - ingen cluster defineret"],"266367750":["Navn"],"267393898":["Notater"],"267943793":["Gendan"],"271285817":["Rolle"],"299255234":["Katalogoversigt"],"311628609":["Eksempel"],"330376117":["Hukommelsesforbrug"],"337799720":["Katalog"],"340849291":["Subscriptionnøgle"],"343848780":["kører"],"348688142":["Inkludér valgte VMs"],"358918290":["Ressourcer"],"368268244":["Kopiér data"],"370850709":["Komprimering"],"397479987":["Indlæser..."],"400411952":["Realm"],"407871486":["Kommentar"],"40861564":["Upload"],"413621352":["Opret CT"],"420340861":["Opret"],"420819256":["Fornavn"],"43254447":["hurtig"],"433860734":["Standard"],"434265056":["Efternavn"],"43540570":["Brug LUNs direkte"],"440640172":["Genindlæs"],"443800475":["Sprog"],"455261812":["Ejer"],"478602302":["Aktivéret"],"499155077":["Diskstørrelse"],"499362324":["Tilføj"],"522841778":["Færdig"],"526638236":["Storage {0} på node {1}"],"529077071":["Aktiv"],"557963277":["Rettigheder"],"562285039":["Bekræft"],"564498461":["Fjern"],"571956348":["Processorer"],"583450315":["Ingen ændringer"],"599530703":["Servertid"],"6222351":["Status"],"638979907":["CD/DVD-drev"],"641424522":["Volume"],"642223740":["Størrelse"],"669966492":["Send e-mail til"],"69963780":["Proxmox VE Login"],"711771863":["Sluttid"],"750979128":["Adgangskode"],"756268998":["Fallback Server"],"761816144":["Subnet mask"],"765964251":["ingen"],"772725124":["Besked"],"793046412":["Genstart"],"806397589":["Afventende ændringer"],"823271646":["Premium"],"838400325":["Ressourcepulje"],"866399792":["Ja"],"872795939":["Formularfelter sendes ikke med ugyldige værdier"],"879231789":["Node"],"888004358":["Storage"],"888343212":["Rekursiv"],"893259077":["Indstillinger"],"910411524":["Tjeneste"],"91525164":["Gruppe"],"947972530":["Tastaturopsætning"],"966695021":["Opgaver"],"96965162":["Opret VM"],"973659646":["Serveradresse"],"974743969":["Konsol"],"974794979":["Forbindelsesfejl"],"980565689":["Virtuel Maskine"],"989937162":["Vent venligst..."]};
__proxmox_i18n_plurals_msgcat__ = {};

function fnv31a(text) {
    var len = text.length;
    var hval = 0x811c9dc5;
    for (var i = 0; i < len; i++) {
        var c = text.charCodeAt(i);
        hval ^= c;
        hval += (hval << 1) + (hval << 4) + (hval << 7) + (hval << 8) + (hval << 24);
    }
    hval &= 0x7fffffff;
    return hval;
}

function gettext(buf) {
    var digest = fnv31a(buf);
    var data = __proxmox_i18n_msgcat__[digest];
    if (!data) {
        return buf;
    }
    return data[0] || buf;
}

function ngettext(singular, plural, n) {
    const msg_idx = Number((n != 1));
    const digest = fnv31a(singular);
    const translation = __proxmox_i18n_plurals_msgcat__[digest];
    if (!translation || msg_idx >= translation.length) {
        if (n === 1) {
            return singular;
        } else {
            return plural;
        }
    }
    return translation[msg_idx];
}
