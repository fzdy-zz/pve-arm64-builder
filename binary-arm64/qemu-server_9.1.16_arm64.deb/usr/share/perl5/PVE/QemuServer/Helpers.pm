package PVE::QemuServer::Helpers;

use strict;
use warnings;

use File::stat;
use IO::File;
use JSON;

use PVE::Cluster;
use PVE::INotify;
use PVE::ProcFSTools;
use PVE::Tools;

use base 'Exporter';
our @EXPORT_OK = qw(
    min_version
    config_aware_timeout
    get_iscsi_initiator_name
    kvm_user_version
    parse_number_sets
    windows_version
    get_host_arch
);

my $nodename = PVE::INotify::nodename();

my $arch_to_qemu_binary = {
    aarch64 => '/usr/bin/qemu-system-aarch64',
    loongarch64 => '/usr/bin/qemu-system-loongarch64',
    riscv64 => '/usr/bin/qemu-system-riscv64',
    x86_64 => '/usr/bin/qemu-system-x86_64',
};

# wrapper around the Tools helper, having it here makes it easier to mock for testing
sub get_host_arch {
    return PVE::Tools::get_host_arch();
}

sub get_command_for_arch($) {
    my ($arch) = @_;
    return '/usr/bin/kvm' if get_host_arch() eq $arch; # i.e. native arch

    my $cmd = $arch_to_qemu_binary->{$arch}
        or die "don't know how to emulate architecture '$arch'\n";
    return $cmd;
}

sub get_vm_arch {
    my ($conf) = @_;
    return $conf->{arch} // get_host_arch();
}

my $kvm_user_version = {};
my $kvm_mtime = {};

sub kvm_user_version {
    my ($binary) = @_;

    $binary //= get_command_for_arch(get_host_arch()); # get the native arch by default
    my $st = stat($binary);

    my $cachedmtime = $kvm_mtime->{$binary} // -1;
    return $kvm_user_version->{$binary}
        if $kvm_user_version->{$binary}
        && $cachedmtime == $st->mtime;

    $kvm_user_version->{$binary} = 'unknown';
    $kvm_mtime->{$binary} = $st->mtime;

    my $code = sub {
        my $line = shift;
        if ($line =~ m/^QEMU( PC)? emulator version (\d+\.\d+(\.\d+)?)(\.\d+)?[,\s]/) {
            $kvm_user_version->{$binary} = $2;
        }
    };

    eval { PVE::Tools::run_command([$binary, '--version'], outfunc => $code); };
    warn $@ if $@;

    return $kvm_user_version->{$binary};
}

# Paths and directories

# FIXME: MAJOR VERSION: use /run/qemu-server everywhere instead of mixing /run and /var/run and rely
# on debian/tmpfiles config to create the directory.
our $var_run_tmpdir = "/var/run/qemu-server";
mkdir $var_run_tmpdir;

sub qmp_socket {
    my ($peer) = @_;
    my ($id, $type) = $peer->@{qw(id type)};
    return "${var_run_tmpdir}/${id}.${type}";
}

sub qsd_pidfile_name {
    my ($id) = @_;
    return "${var_run_tmpdir}/qsd-${id}.pid";
}

sub qsd_fuse_export_cleanup_files {
    my ($id) = @_;

    # Usually, /var/run is a symlink to /run. It needs to be the exact path for checking if mounted
    # below. Note that Cwd::realpath() needs to be done on the directory already. Doing it on the
    # file does not work if the storage daemon is not running and the FUSE is still mounted.
    my ($real_dir) = Cwd::realpath($var_run_tmpdir) =~ m/^(.*)$/; # untaint
    if (!$real_dir) {
        warn "error resolving $var_run_tmpdir - not checking for left-over QSD files\n";
        return;
    }

    my $mounts = PVE::ProcFSTools::parse_proc_mounts();

    PVE::Tools::dir_glob_foreach(
        $real_dir,
        "qsd-${id}-.*\.fuse",
        sub {
            my ($file) = @_;
            my $path = "${real_dir}/${file}";
            if (grep { $_->[1] eq $path } $mounts->@*) {
                PVE::Tools::run_command(['umount', $path]);
            }
            unlink $path;
        },
    );
}

sub qsd_fuse_export_path {
    my ($id, $export_name) = @_;
    return "${var_run_tmpdir}/qsd-${id}-${export_name}.fuse";
}

sub vm_pidfile_name {
    my ($vmid) = @_;
    return "${var_run_tmpdir}/$vmid.pid";
}

sub vnc_socket {
    my ($vmid) = @_;
    return "${var_run_tmpdir}/$vmid.vnc";
}

# Parse the cmdline of a running kvm/qemu-* process and return arguments as hash
sub parse_cmdline {
    my ($pid) = @_;

    my $fh = IO::File->new("/proc/$pid/cmdline", "r");
    if (defined($fh)) {
        my $line = <$fh>;
        $fh->close;
        return if !$line;
        my @param = split(/\0/, $line);

        my $cmd = $param[0];
        return if !$cmd || ($cmd !~ m|kvm$| && $cmd !~ m@(?:^|/)qemu-[^/]+$@);

        my $phash = {};
        my $pending_cmd;
        for (my $i = 0; $i < scalar(@param); $i++) {
            my $p = $param[$i];
            next if !$p;

            if ($p =~ m/^--?(.*)$/) {
                if ($pending_cmd) {
                    $phash->{$pending_cmd} = {};
                }
                $pending_cmd = $1;
            } elsif ($pending_cmd) {
                $phash->{$pending_cmd} = { value => $p };
                $pending_cmd = undef;
            }
        }

        return $phash;
    }
    return;
}

my sub instance_running_locally {
    my ($pidfile) = @_;

    if (my $fd = IO::File->new("<$pidfile")) {
        my $st = stat($fd);
        my $line = <$fd>;
        close($fd);

        my $mtime = $st->mtime;
        if ($mtime > time()) {
            warn "file '$pidfile' modified in future\n";
        }

        if ($line =~ m/^(\d+)$/) {
            my $pid = $1;
            my $cmdline = parse_cmdline($pid);
            if (
                $cmdline
                && defined($cmdline->{pidfile})
                && $cmdline->{pidfile}->{value}
                && $cmdline->{pidfile}->{value} eq $pidfile
            ) {
                if (my $pinfo = PVE::ProcFSTools::check_process_running($pid)) {
                    return $pid;
                }
            }
        }
    }

    return;
}

sub qsd_running_locally {
    my ($id) = @_;

    my $pidfile = qsd_pidfile_name($id);

    return instance_running_locally($pidfile);
}

sub vm_running_locally {
    my ($vmid) = @_;

    my $pidfile = vm_pidfile_name($vmid);

    return instance_running_locally($pidfile);
}

sub min_version {
    my ($verstr, $major, $minor, $pve) = @_;

    if ($verstr =~ m/^(\d+)\.(\d+)(?:\.(\d+))?(?:\+pve(\d+))?/) {
        return 1 if version_cmp($1, $major, $2, $minor, $4, $pve) >= 0;
        return 0;
    }

    die "internal error: cannot check version of invalid string '$verstr'";
}

# gets in pairs the versions you want to compares, i.e.:
# ($a-major, $b-major, $a-minor, $b-minor, $a-extra, $b-extra, ...)
# returns 0 if same, -1 if $a is older than $b, +1 if $a is newer than $b
sub version_cmp {
    my @versions = @_;

    my $size = scalar(@versions);

    return 0 if $size == 0;

    if ($size & 1) {
        my (undef, $fn, $line) = caller(0);
        die "cannot compare odd count of versions, called from $fn:$line\n";
    }

    for (my $i = 0; $i < $size; $i += 2) {
        my ($left, $right) = splice(@versions, 0, 2);
        $left //= 0;
        $right //= 0;

        return 1 if $left > $right;
        return -1 if $left < $right;
    }
    return 0;
}

sub config_aware_timeout {
    my ($config, $memory, $is_suspended) = @_;
    my $timeout = 30;

    # Based on user reported startup time for vm with 512GiB @ 4-5 minutes
    if (defined($memory) && $memory > 30720) {
        $timeout = int($memory / 1024);
    }

    # When using PCI passthrough, users reported much higher startup times,
    # growing with the amount of memory configured. Constant factor chosen
    # based on user reports.
    if (grep(/^hostpci[0-9]+$/, keys %$config)) {
        $timeout *= 4;
    }

    if ($is_suspended && $timeout < 300) {
        $timeout = 300;
    }

    if ($config->{hugepages} && $timeout < 150) {
        $timeout = 150;
    }

    # Some testing showed that adding a NIC increased the start time by ~450ms
    # consistently across different NIC models, options and already existing
    # number of NICs.
    # So 10x that to account for any potential system differences seemed
    # reasonable. User reports with real-life values (20+: ~50s, 25: 45s, 17: 42s)
    # also make this seem a good value.
    my $nic_count = scalar(grep { /^net\d+/ } keys %{$config});
    $timeout += $nic_count * 5;

    return $timeout;
}

sub get_node_pvecfg_version {
    my ($node) = @_;

    my $nodes_version_info = PVE::Cluster::get_node_kv('version-info', $node);
    return if !$nodes_version_info->{$node};

    my $version_info = decode_json($nodes_version_info->{$node});
    return $version_info->{version};
}

sub pvecfg_min_version {
    my ($verstr, $major, $minor, $release) = @_;

    return 0 if !$verstr;

    if ($verstr =~ m/^(\d+)\.(\d+)(?:[.-](\d+))?/) {
        return 1 if version_cmp($1, $major, $2, $minor, $3 // 0, $release) >= 0;
        return 0;
    }

    die "internal error: cannot check version of invalid string '$verstr'";
}

sub parse_number_sets {
    my ($set) = @_;
    my $res = [];
    foreach my $part (split(/;/, $set)) {
        if ($part =~ /^\s*(\d+)(?:-(\d+))?\s*$/) {
            die "invalid range: $part ($2 < $1)\n" if defined($2) && $2 < $1;
            push @$res, [$1, $2];
        } else {
            die "invalid range: $part\n";
        }
    }
    return $res;
}

sub windows_version {
    my ($ostype) = @_;

    return 0 if !$ostype;

    my $winversion = 0;

    if ($ostype eq 'wxp' || $ostype eq 'w2k3' || $ostype eq 'w2k') {
        $winversion = 5;
    } elsif ($ostype eq 'w2k8' || $ostype eq 'wvista') {
        $winversion = 6;
    } elsif ($ostype =~ m/^win(\d+)$/) {
        $winversion = $1;
    }

    return $winversion;
}

sub needs_extraction {
    my ($vtype, $fmt) = @_;
    return $vtype eq 'import' && $fmt =~ m/^ova\+(.*)$/;
}

sub get_iscsi_initiator_name {
    my $initiator;

    my $fh = IO::File->new('/etc/iscsi/initiatorname.iscsi') || return;
    while (defined(my $line = <$fh>)) {
        next if $line !~ m/^\s*InitiatorName\s*=\s*([\.\-:\w]+)/;
        $initiator = $1;
        last;
    }
    $fh->close();

    return $initiator;
}

my $_host_bits;

sub get_host_phys_address_bits {
    return $_host_bits if defined($_host_bits);

    my $fh = IO::File->new('/proc/cpuinfo', "r") or return;
    while (defined(my $line = <$fh>)) {
        # hopefully we never need to care about mixed (big.LITTLE) archs
        if ($line =~ m/^address sizes\s*:\s*(\d+)\s*bits physical/i) {
            $_host_bits = int($1);
            $fh->close();
            return $_host_bits;
        }
    }
    $fh->close();
    return; # undef, cannot really do anything..
}

1;
