package PVE::pvecfg;

use strict;
use warnings;

sub package {
    return 'pve-manager';
}

sub version {
    return '9.2.3';
}

sub release {
    return '9.2';
}

sub repoid {
    return 'add37abb73679481';
}

sub version_text {
    return '9.2.3/add37abb73679481';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '9.2.3',
	'release' => '9.2',
	'repoid' => 'add37abb73679481',
    }
}

1;
